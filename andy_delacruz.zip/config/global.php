<?php

return [
    'currentContainerNumber' => 'EPG 20',
];
