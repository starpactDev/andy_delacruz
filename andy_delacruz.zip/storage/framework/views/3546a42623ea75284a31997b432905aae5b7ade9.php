<?php $__env->startSection('content'); ?>
    <style>
        .title {
            color: rgb(18, 49, 133);
            font-size: 24px;
            font-weight: bold;
            margin-bottom:40px;
        }
        .form-container {
          
            margin: auto;
            padding: 20px;
            background: #fffdfd!important;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-check {
            margin-bottom: 10px;
        }
        .form-check-label {
            font-weight: 500;
        }
        .form-check-input {
            transform: scale(1.3);
            margin-right: 10px;
        }
        .form-label {
            font-weight: bold;
            color: rgb(10, 78, 99);
        }
    </style>
    <div class="container mt-4">
        <div class="form-container">
            <h2 class="title text-center">Service Experience Feedback</h2>
            <div class="text-center mb-3">
                <a href="<?php echo e(route('customer.dashboard')); ?>" class="btn btn-secondary">Back to Dashboard</a>
            </div>
            <form method="POST" action="<?php echo e(route('feedback.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="order_pickup_id" value="<?php echo e($orderDetails->id); ?>">

                <!-- Satisfaction -->
                <div class="mb-3">
                    <label class="form-label">How satisfied are you with the overall shipping process?</label>
                    <?php $__currentLoopData = ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="satisfaction" value="<?php echo e($option); ?>" <?php echo e(old('satisfaction') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['satisfaction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Booking Process -->
                <div class="mb-3">
                    <label class="form-label">How easy was it to book your shipment?</label>
                    <?php $__currentLoopData = ['Very Easy', 'Easy', 'Neutral', 'Difficult', 'Very Difficult']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="booking" value="<?php echo e($option); ?>" <?php echo e(old('booking') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['booking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Package Arrival Time -->
                <div class="mb-3">
                    <label class="form-label">Did your package arrive on time?</label>
                    <?php $__currentLoopData = ['Yes, earlier than expected', 'Yes, on time', 'No, slightly delayed', 'No, significantly delayed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="arrival_time" value="<?php echo e($option); ?>" <?php echo e(old('arrival_time') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['arrival_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Package Condition -->
                <div class="mb-3">
                    <label class="form-label">How would you rate the condition of your package upon arrival?</label>
                    <?php $__currentLoopData = ['Excellent – No damage', 'Good – Minor wear', 'Fair – Some damage', 'Poor – Significant damage']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="package_condition" value="<?php echo e($option); ?>" <?php echo e(old('package_condition') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['package_condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tracking Accuracy -->
                <div class="mb-3">
                    <label class="form-label">Was the tracking information accurate and updated regularly?</label>
                    <?php $__currentLoopData = ['Yes', 'Somewhat', 'No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="tracking" value="<?php echo e($option); ?>" <?php echo e(old('tracking') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['tracking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Customer Support -->
                <div class="mb-3">
                    <label class="form-label">Did you contact customer support during your shipping process?</label>
                    <?php $__currentLoopData = ['Yes', 'No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="customer_support" value="<?php echo e($option); ?>" <?php echo e(old('customer_support') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['customer_support'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="form-label">If Yes, How satisfied were you with the assistance received?</label>
                    <?php $__currentLoopData = ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="support_satisfaction" value="<?php echo e($option); ?>">
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['support_satisfaction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="form-label">How would you rate the professionalism of our team?</label>
                    <?php $__currentLoopData = ['Excellent', 'Good', 'Neutral', 'Poor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="professionalism" value="<?php echo e($option); ?>">
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['professionalism'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Recommendations for Improvement -->
                <div class="mb-3">
                    <label class="form-label">What areas do you think we could improve? (Check all that apply)</label>
                    <?php $__currentLoopData = ['Faster delivery', 'Better package handling', 'Improved tracking system', 'Lower shipping costs', 'Better customer service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="improvements[]" value="<?php echo e($option); ?>" <?php echo e(is_array(old('improvements')) && in_array($option, old('improvements')) ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-2">
                        <input type="text" class="form-control" name="other_improvements" value="<?php echo e(old('other_improvements')); ?>" placeholder="Other (please specify)">
                    </div>
                    <?php $__errorArgs = ['improvements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Recommendation -->
                <div class="mb-3">
                    <label class="form-label">Would you recommend our shipping service to others?</label>
                    <?php $__currentLoopData = ['Yes, definitely', 'Maybe', 'No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="recommend" value="<?php echo e($option); ?>" <?php echo e(old('recommend') == $option ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($option); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['recommend'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Comments -->
                <div class="mb-3">
                    <label class="form-label">Any additional comments or suggestions?</label>
                    <textarea class="form-control" name="comments" rows="3" placeholder="Your feedback..."><?php echo e(old('comments')); ?></textarea>
                    <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Submit Button -->
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit Feedback</button>
                </div>
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: "<?php echo e(session('success')); ?>",
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'OK'
    });
</script>
<?php endif; ?>

<?php if($errors->any()): ?>
<script>
    let errorMessages = '<div style="text-align: left;">';

    <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var question = ''; // Use var instead of let

        switch (<?php echo json_encode($field, 15, 512) ?>) {
            case 'satisfaction': question = '🌟 <b>How satisfied are you with the overall shipping process?</b>'; break;
            case 'booking': question = '📦 <b>How easy was it to book your shipment?</b>'; break;
            case 'arrival_time': question = '⏳ <b>Did your package arrive on time?</b>'; break;
            case 'package_condition': question = '📦 <b>How would you rate the condition of your package upon arrival?</b>'; break;
            case 'tracking': question = '📍 <b>Was the tracking information accurate and updated regularly?</b>'; break;
            case 'customer_support': question = '📞 <b>Did you contact customer support during your shipping process?</b>'; break;
            case 'support_satisfaction': question = '🤝 <b>If Yes, how satisfied were you with the assistance received?</b>'; break;
            case 'professionalism': question = '👨‍💼 <b>How would you rate the professionalism of our team?</b>'; break;
            case 'improvements': question = '🚀 <b>What areas do you think we could improve?</b>'; break;
            case 'recommend': question = '👍 <b>Would you recommend our shipping service to others?</b>'; break;
            case 'comments': question = '📝 <b>Any additional comments or suggestions?</b>'; break;
            default: question = '❓ <b>Unknown Question</b>'; break;
        }

        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            errorMessages += `<p style="margin-bottom: 8px; padding: 10px; background: #fff3f3; border-left: 5px solid #e74c3c; border-radius: 5px; color: #c0392b;">
                ${question} <br> 🔴 <i><?php echo json_encode($message, 15, 512) ?></i>
            </p>`;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    errorMessages += '</div>';

    Swal.fire({
        icon: 'error',
        title: '⚠️ Validation Errors',
        html: errorMessages,
        confirmButtonColor: '#d33',
        confirmButtonText: 'OK',
        width: '600px',
        customClass: {
            popup: 'swal-wide'
        }
    });
</script>
<?php endif; ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('CustomerDashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andy\resources\views/CustomerDashboard/survey/form.blade.php ENDPATH**/ ?>