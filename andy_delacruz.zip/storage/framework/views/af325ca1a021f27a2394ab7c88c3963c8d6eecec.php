<div id="filteredTablesContainer" class="month-table">
    <div class="table-responsive mt-3">
        <table class="tablesaw no-wrap v-middle table-hover table" data-tablesaw>
            <thead>
                <tr>
                    <th class="border-0 text-muted fw-normal">Order Id</th>

                    <th class="border-0 text-muted fw-normal">Container ID</th>
                    <th class="border-0 text-muted fw-normal">Customer Name</th>
                    <th class="border-0 text-muted fw-normal">Receiver Info</th>

                    <th class="border-0 text-muted fw-normal">Payment Status</th>
                    <th class="border-0 text-muted fw-normal">Assigned To</th>
                    <th class="border-0 text-muted fw-normal">View Invoices</th>
                </tr>
            </thead>
            <tbody>
                <?php if($assignedOrders->isEmpty()): ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            <h6 class="font-weight-medium mb-0 text-muted">No packages have been assigned yet.</h6>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $assignedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <h6 class="font-weight-medium mb-0"><?php echo e($order->order_number); ?></h6>
                            </td>
                            <td>
                                <h6 class="font-weight-medium mb-0"><?php echo e($order->orderPickup->container_number ?? 'N/A'); ?></h6>
                            </td>
                            <td>
                                <h6 class="font-weight-medium mb-0">
                                    <?php echo e($order->orderPickup->sender->first_name ?? 'N/A'); ?>

                                    <?php echo e($order->orderPickup->sender->last_name ?? 'N/A'); ?>

                                </h6>
                            </td>
                            <td>
                                <h6 class="font-weight-medium mb-0">
                                    <?php echo e($order->orderPickup->receiver->first_name ?? 'N/A'); ?>

                                    <?php echo e($order->orderPickup->receiver->last_name ?? 'N/A'); ?>

                                </h6>
                                <small class="text-muted">
                                    <i class=" text-dark me-1" aria-hidden="true">PROVINCE :</i>
                                    <?php echo e($order->orderPickup->receiver->province ?? ''); ?>

                                </small>
                                <br/>
                                <small class="text-muted">
                                    <i class=" text-dark me-1" aria-hidden="true">CITY :</i>
                                    <?php echo e($order->orderPickup->receiver->city ?? ''); ?>

                                </small>
                            </td>
                            <td>
                                <h6 class="font-weight-medium mb-0">
                                    <span class="badge <?php echo e($order->orderPickup->is_completed === 0 ? 'bg-danger' : 'bg-success'); ?>">
                                        <?php echo e($order->orderPickup->is_completed === 0 ? 'Due' : 'Paid'); ?>

                                    </span>
                                </h6>
                            </td>

                            <td>
                                <h6 class="font-weight-medium mb-0"><?php echo e($order->driver->name ?? 'Unassigned'); ?></h6>

                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-light-warning text-dark custom-size"
                                        onclick="window.location.href='<?php echo e(route('user.order_overview', $order->id)); ?>'">
                                    <i data-feather="package" class="feather-sm"></i> View
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\andy\resources\views/admin/pages/table8.blade.php ENDPATH**/ ?>