<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="card shadow-lg border-0 rounded">
        <div class="card-header bg-info text-center">
            <?php
            $order_number = \App\Models\OrderPickUp::where('id', $survey->order_pickup_id)->first();
            $sender = \App\Models\Sender::where('id', $order_number->sender_id)->first();
            ?>
            <h3 style="color:white!important">Survey Feedback for Order #<?php echo e($order_number->order_number); ?></h3>
        </div>
        <div class="card-body">
            <!-- Sender Information -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="alert alert-light border shadow-sm">
                        <h5 class="text-primary"><i class="fas fa-user"></i> Customer Information</h5>
                        <hr>
                        <p><strong>Order #</strong> <?php echo e($order_number->order_number); ?></p>
                        <p><strong>Name:</strong> <?php echo e($sender->first_name); ?> <?php echo e($sender->last_name); ?></p>
                        <p><strong>Email:</strong> <?php echo e($sender->email); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($sender->cell ?? $sender->telephone); ?></p>
                        <p><strong>Address:</strong> <?php echo e($sender->street_address); ?>,
                            <?php if($sender->apt): ?> Apt <?php echo e($sender->apt); ?>, <?php endif; ?>
                            <?php echo e($sender->city); ?>, <?php echo e($sender->state); ?> - <?php echo e($sender->zip); ?>

                        </p>
                    </div>
                </div>
            </div>

            <!-- Survey Table -->
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th style="color:rgb(151, 46, 14)">Questions</th>
                                <td style="color:rgb(10, 119, 68)">Answers</td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Overall Satisfaction</th>
                                <td><?php echo e($survey->satisfaction); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Booking Process</th>
                                <td><?php echo e($survey->booking); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Package Arrival Time</th>
                                <td><?php echo e($survey->arrival_time); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Package Condition</th>
                                <td><?php echo e($survey->package_condition); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Tracking Accuracy</th>
                                <td><?php echo e($survey->tracking); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Customer Support Contacted</th>
                                <td><?php echo e($survey->customer_support); ?></td>
                            </tr>
                            <?php if($survey->customer_support == 'Yes'): ?>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Support Satisfaction</th>
                                <td><?php echo e($survey->support_satisfaction); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Professionalism of Team</th>
                                <td><?php echo e($survey->professionalism); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Recommended Improvements</th>
                                <td>
                                    <?php if(!empty($survey->improvements)): ?>
                                        <ul>
                                            <?php $__currentLoopData = $survey->improvements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $improvement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($improvement); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                    <?php if(!empty($survey->other_improvements)): ?>
                                        <p><strong>Other:</strong> <?php echo e($survey->other_improvements); ?></p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Would Recommend Service?</th>
                                <td><?php echo e($survey->recommend); ?></td>
                            </tr>
                            <tr>
                                <th style="color:rgb(14, 68, 75)">Additional Comments</th>
                                <td><?php echo e($survey->comments ?? 'No additional comments.'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card-footer text-center">
            <a href="<?php echo e(route('customer.dashboard')); ?>" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>
</div>

<style>
    .card {
        border-radius: 15px;
    }
    th {
        background-color: #f8f9fa;
        width: 40%;
    }
    td {
        font-weight: 500;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CustomerDashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andy\resources\views/CustomerDashboard/survey/view_survey.blade.php ENDPATH**/ ?>