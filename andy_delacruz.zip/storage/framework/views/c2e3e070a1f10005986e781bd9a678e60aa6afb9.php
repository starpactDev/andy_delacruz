<?php $__env->startSection('content'); ?>
    <style>
        .title {
            color: rgb(10, 78, 99);
        }
    </style>
    <!-- -------------------------------------------------------------- -->
    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <!-- Row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h4 class="mb-0 text-white">Order overview</h4>
                    </div>
                    <form class="form-horizontal">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-sm-3 text-end ms-auto" style="margin-right:20px; margin-top:20px;">
                                <address>
                                    <h4 class="fw-bold" style="color:rgb(12, 12, 56)">Invoice Details:</h4>
                                    <p>
                                        <b>Invoice #: </b>EPG 20-0001 <br />
                                        <b>Issue Date: </b>13 Sep 2024 <br />
                                        <b>Order ID: </b>EPG-4096 <br />
                                        <b>Container ID: </b>EPG 20 <br />
                                        <b>Driver Name: </b>Jose Manuel Gonzalbz
                                    </p>
                                </address>
                            </div>
                            </div>
                            <div class="card-body">
                                <h4 class="card-title mb-0" style="color:rgb(12, 12, 56)">Sender Info</h4>
                            </div>
                            <div class="card-body border-top">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">First
                                                Name:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">John</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">Last
                                                Name:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Doe</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Email:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">john.doe@example.com</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">Street
                                                Address:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">1234 Elm Street</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">Apt
                                                #:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">567</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">City:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Springfield</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">State:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">IL</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">ZIP:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">62704</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Tel:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">(555) 123-4567</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Cell:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">(555) 987-6543</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                            </div>

                            <div class="card-body">
                                <h3 class="card-title mb-0 "style="color:rgb(12, 12, 56)">Recipient Details</h3>


                            </div>
                            <div class="card-body border-top">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">First
                                                Name:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Jane</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">Last
                                                Name:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Smith</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label class="control-label text-end col-md-4 font-weight-medium title">Second
                                                Last
                                                Name:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Johnson</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Nickname:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Janie</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Email:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">jane.smith@example.com</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Address:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">123 Maple Street</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Neighborhood:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Downtown</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">City:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Metropolis</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Province:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Distrito Nacional</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Reference:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">Near the big park</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Tel:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">(123) 456-7890</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">Cell:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">(987) 654-3210</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-4">
                                        <div class="form-group row py-3">
                                            <label
                                                class="control-label text-end col-md-4 font-weight-medium title">WhatsApp:</label>
                                            <div class="col-md-8">
                                                <p class="form-control-static">(555) 123-4567</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                            </div>
                            <div class="card-body">
                                <h3 class="card-title mb-0 "style="color:rgb(12, 12, 56)">Items Description</h3>


                            </div>
                            <div class="card-body border-top">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-responsive m-t-40" style="clear: both">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center">#</th>
                                                        <th>Items</th>
                                                        <th class="text-end">QTY</th>
                                                        <th class="text-end">Price</th>
                                                        <th class="text-end">Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="text-center">1</td>
                                                        <td>Calendar App Customization</td>
                                                        <td class="text-end">1</td>
                                                        <td class="text-end">$120</td>
                                                        <td class="text-end">$120</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">2</td>
                                                        <td>Chat App Customization</td>
                                                        <td class="text-end">1</td>
                                                        <td class="text-end">$230</td>
                                                        <td class="text-end">$230</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">3</td>
                                                        <td>Laravel Integration</td>
                                                        <td class="text-end">1</td>
                                                        <td class="text-end">$405</td>
                                                        <td class="text-end">$405</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">4</td>
                                                        <td>Backend UI Design</td>
                                                        <td class="text-end">1</td>
                                                        <td class="text-end">$2500</td>
                                                        <td class="text-end">$2500</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="pull-right m-t-30 text-end">
                                            <table class="table invoice-summary-table">
                                                <tr class="sub-total-row">
                                                    <td><b>Sub - Total:</b></td>
                                                    <td>$3255</td>
                                                </tr>
                                                

                                                <tr class="sub-total-row">
                                                    <td><b>Discount:</b></td>
                                                    <td>$10</td>
                                                </tr>
                                                <tr class="sub-total-row">
                                                    <td>

                                                    </td>
                                                    <td>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h3><b>Grand Total:</b></h3>
                                                    </td>
                                                    <td>
                                                        <h3>$3945</h3>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Deposit/Value Paid:</b></td>
                                                    <td>
                                                        <h3 style="color: green">$10</h3>
                                                    </td>
                                                </tr>
                                                <tr class="sub-total-row">
                                                    <td><b>Balance Due :</b></td>
                                                    <td>
                                                        <h3 style="color: red">$3935</h3>
                                                    </td>
                                                </tr>
                                                <tr class="payment-method-row">
                                                    <td><b>Payment Methods:</b></td>
                                                    <td>
                                                        <table class="table invoice-summary-table">
                                                            <tbody>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label"
                                                                            for="cash">Cash (US)</label></td>
                                                                </tr>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label"
                                                                            for="paypal">Paypal</label></td>
                                                                </tr>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label"
                                                                            for="zelle">Zelle</label></td>
                                                                </tr>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label"
                                                                            for="cashApp">Cash App</label></td>
                                                                </tr>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label"
                                                                            for="creditCard">Credit Cards</label></td>
                                                                </tr>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label" for="payLater">Pay
                                                                            Later</label></td>
                                                                </tr>
                                                                <tr class="sub-total-row">
                                                                    
                                                                    <td><label class="form-check-label"
                                                                            for="bankDeposit">Bank Deposit (Chase Bank
                                                                            # 597817520)</label></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr class="sub-total-row">
                                                    <td><b>Payment Location :</b></td>
                                                    <td><b>Dom Rep</b></td>
                                                </tr>

                                                <tr class="sub-total-row">
                                                    <td><b>Total packages to be delivered :</b></td>
                                                    <td><b>4</b></td>
                                                </tr>

                                            </table>
                                        </div>
                                        <div class="clearfix"></div>

                                    </div>
                                </div>
                            </div>
                        </div>


                        <hr />
                        <div class="form-actions">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <div class="col-md-offset-3 col-md-9">
                                                <button type="button" class="btn btn-danger" id="backButton">
                                                    <i class="fa fa-arrow-left"></i> Back
                                                </button>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4"></div>
                                </div>
                            </div>
                        </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Row -->
    <!-- -------------------------------------------------------------- -->
    <!-- End PAge Content -->
    <!-- -------------------------------------------------------------- -->
    </div>
    <!-- -------------------------------------------------------------- -->
    <!-- End Container fluid  -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        document.getElementById('backButton').addEventListener('click', function() {

            window.location.href = "<?php echo e(route('driver.due_amount')); ?>";
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andy\resources\views/admin/pages/dom_driver/order_overview.blade.php ENDPATH**/ ?>