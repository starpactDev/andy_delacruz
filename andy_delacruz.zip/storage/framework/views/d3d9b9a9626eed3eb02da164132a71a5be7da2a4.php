<?php $__env->startSection('content'); ?>
    <style>
        .hidden {
            display: none;
        }
    </style>
    <style>
        .underline-row td {
            border-bottom: 2px solid #d8d0d0;
        }
    </style>
    <style>
        .fixed-width {
            width: 300px;
            /* Adjust the width as needed */
            text-align: center;
        }

        .item {

            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <style>
        table,
        th,
        td {
            border: none;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
        }
    </style>
    <div class="container-fluid">
        <div class="col-12">
            <div class="card">
                <div class="border-bottom title-part-padding">
                    <h4 class="card-title mb-0">Create New Shipping</h4>
                </div>
                <div class="card-body wizard-content">
                    <h6 class="card-subtitle mb-3"></h6>
                    <form action="#" class="tab-wizard wizard-circle">

                        <!-- Step 1 -->
                        <h6>Sender & Recipient Details</h6>
                        <section>

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="containerNumber">INVOICE #:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text fixed-width" id="basic-addon1"
                                                style="background-color:#17a8ad;color:white;font-size:20px;">EPG
                                                20-0001</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="containerNumber">ISSUE DATE:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text fixed-width" id="basic-addon1"
                                                style="background-color:#ad1794;color:white;font-size:20px;">
                                                <?php echo e(\Carbon\Carbon::now()->format('d M Y')); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="containerNumber">ORDER ID:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1"
                                                style="background-color:#7617ad;color:white;font-size:20px;border-right: none; display:inline-flex;align-items:center;">EPG
                                                -</span>
                                            <input type="text" class="form-control" id="orderNumber" name="orderNumber"
                                                maxlength="4" value="2401"
                                                style="background-color:#7617ad;color:white;font-size:20px;border-left: none; padding: 0.375rem 0.75rem; display:inline-flex; align-items:center;"
                                                aria-describedby="basic-addon1">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="containerNumber">CONTAINER ID:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text fixed-width" id="basic-addon1"
                                                style="background-color:#17ad30;color:white;font-size:20px;">EPG 20</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="driver_name">DRIVER PICKUP NAME:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text fixed-width" id="basic-addon1"
                                                style="background-color:#ff7300;color:white;font-size:20px;"><?php echo e(Auth::user()->name); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h3 class="mb-3 mt-5 fw-bold">Sender Details</h3>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="senderName">Sender First Name:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">First Name</span>
                                            <input type="text" id="senderName" name="senderName" class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="senderName">Sender Last Name:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">Last Name</span>
                                            <input type="text" id="senderName" name="senderName" class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="senderName">Sender Email:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">@</span>
                                            <input type="email" id="senderEmail" name="senderEmail" class="form-control">
                                        </div>

                                    </div>
                                </div>


                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="address">Street Address</label>
                                        <input type="text" id="address" name="address" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="apt">Apt #</label>
                                        <input type="text" id="apt" name="apt" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="city">City</label>
                                        <input type="text" id="city" name="city" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="address">State</label>
                                        <input type="text" id="state" name="state" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="address">ZIP</label>
                                        <input type="text" id="zip" name="zip" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="senderTel">Tel:</label>
                                        <input type="text" id="senderTel" name="senderTel" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="senderTel">Cell:</label>
                                        <input type="text" id="senderCell" name="senderCell" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <h3 class="mb-3 fw-bold">Recipient Details</h3>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientName">First Name:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">Name</span>
                                            <input type="text" id="recipientName" name="recipientName"
                                                class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientLastName">Last Name:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">Name</span>
                                            <input type="text" id="recipientLastName" name="recipientLastName"
                                                class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientSecondLastName">Second Last Name:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">Name</span>
                                            <input type="text" id="recipientSecondLastName"
                                                name="recipientSecondLastName" class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientNickname">Nickname:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">Name</span>
                                            <input type="text" id="recipientNickname" name="recipientNickname"
                                                class="form-control">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientEmail">Email:</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1">@</span>
                                            <input type="email" id="recipientEmail" name="recipientEmail"
                                                class="form-control">
                                        </div>

                                    </div>
                                </div>


                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientAddress"> Address</label>
                                        <input type="text" id="recipientAddress" name="recipientAddress"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientNeighborhood">Neighborhood:</label>
                                        <input type="text" id="recipientNeighborhood" name="recipientNeighborhood"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientCity">City:</label>
                                        <input type="text" id="recipientCity" name="recipientCity"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="province">Province :</label>
                                        <select class="form-select" id="province" name="province">
                                            <option value="">Select Province</option>
                                            <option value="Azua">Azua</option>
                                            <option value="Bahoruco">Bahoruco</option>
                                            <option value="Barahona">Barahona</option>
                                            <option value="Dajabon">Dajabon</option>
                                            <option value="Distrito Nacional">Distrito Nacional</option>
                                            <option value="Duarte">Duarte</option>
                                            <option value="El Seibo">El Seibo</option>
                                            <option value="Elias Piña">Elias Piña</option>
                                            <option value="Espaillat">Espaillat</option>
                                            <option value="Hato Mayor">Hato Mayor</option>
                                            <option value="Hermanas Mirabal">Hermanas Mirabal</option>
                                            <option value="Independencia">Independencia</option>
                                            <option value="La Altagracia">La Altagracia</option>
                                            <option value="La Romana">La Romana</option>
                                            <option value="La Vega">La Vega</option>
                                            <option value="María Trinidad Sanchez">María Trinidad Sanchez</option>
                                            <option value="Monseñor Nouel">Monseñor Nouel</option>
                                            <option value="Monte Plata">Monte Plata</option>
                                            <option value="Montecristi">Montecristi</option>
                                            <option value="Pedernale">Pedernale</option>
                                            <option value="Peravia">Peravia</option>
                                            <option value="Puerto Plata">Puerto Plata</option>
                                            <option value="Samana">Samana</option>
                                            <option value="San Cristobal">San Cristobal</option>
                                            <option value="San Jose de Ocoa">San Jose de Ocoa</option>
                                            <option value="San Juan">San Juan</option>
                                            <option value="San Pedro de Macoris">San Pedro de Macoris</option>
                                            <option value="Sanchez Ramirez">Sanchez Ramirez</option>
                                            <option value="Santiago">Santiago</option>
                                            <option value="Santiago Rodriguez">Santiago Rodriguez</option>
                                            <option value="Santo Domingo">Santo Domingo</option>
                                            <option value="Valverde">Valverde</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="reference">Reference:</label>
                                        <textarea id="reference" class="form-control" name="reference" rows="4"></textarea>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientTel">Tel:</label>
                                        <input type="text" id="recipientTel" name="recipientTel"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientCell">Cell:</label>
                                        <input type="text" id="recipientCell" name="recipientCell"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="recipientWhatsApp">WhatsApp:</label>
                                        <input type="text" id="recipientWhatsApp" name="recipientWhatsApp"
                                            class="form-control">
                                    </div>
                                </div>
                                
                            </div>




                        </section>

                        <!-- Step 3 -->
                        <h6>Item Descriptions </h6>
                        <section>
                            <h3>Item Descriptions</h3>
                            <div class="row">

                                <table id="itemList" class="table   table-striped">
                                    <thead>
                                        <tr>
                                            <th>Quantity</th>
                                            <th>Item Description</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="item">
                                            <td>
                                                <input type="number" id="quantity" name="quantity[]"
                                                    class="form-control" required>
                                            </td>
                                            <td>
                                                <input type="text" id="itemDescription" name="itemDescription[]"
                                                    class="form-control" required>
                                            </td>
                                            <td>
                                                <input type="text" id="itemPrice" name="itemPrice[]"
                                                    class="form-control" required>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                                <button type="button" id="addItem" class="btn btn-primary m-3">Add More Item</button>

                                <h3 style="color:rgb(16, 16, 82)">Payment Details:</h3>
                                <table class="table">
                                    <tbody>

                                        <tr>
                                            <td><b>Total:</b></td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">$</span>
                                                    <input type="text" id="total" name="total"
                                                        class="form-control">
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td><b>Discount:</b></td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">$</span>
                                                    <input type="text" id="discount" name="discount"
                                                        class="form-control">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Grand Total Amount:</b></td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">$</span>
                                                    <input type="text" id="grandTotal" name="grandTotal"
                                                        class="form-control">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="underline-row">
                                            <td colspan="2"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Total number of packages to be delivered:</b></td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">#</span>
                                                    <input type="text" id="total_package" name="total_package"
                                                        class="form-control">
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                
                            </div>

                        </section>
                        <!-- Step 4 -->

                        <h6>Payment Info</h6>
                        <section>


                            <h5 style="color:rgb(16, 16, 82)">Payment Methods:</h5>
                            <div class="mb-3 row">
                                <label class="col-sm-3 text-end control-label col-form-label"></label>
                                <div class="col-sm-9">
                                    <div class="form-check">
                                        <input type="radio" id="cash" name="paymentMethod" value="cash"
                                            class="form-check-input">
                                        <label class="form-check-label" for="cash">Cash (US)</label>
                                    </div>
                                    <div id="cashInfo" class="hidden mt-2 mb-2">
                                        <form>
                                            <div class="input-group">

                                                <input type="text" id="amountConfirmationNumber"
                                                    name="amountConfirmationNumber" placeholder="Enter Amount"
                                                    class="form-control">

                                                <button class="btn btn-light-info text-info font-weight-medium"
                                                    type="button">Submit</button>

                                            </div>

                                        </form>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="paypal" name="paymentMethod" value="paypal"
                                            class="form-check-input">
                                        <label for="paypal" class="form-check-label">Paypal</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="zelle" name="paymentMethod" value="zelle"
                                            class="form-check-input">
                                        <label for="zelle" class="form-check-label">Zelle</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="cashApp" name="paymentMethod" value="cashApp"
                                            class="form-check-input">
                                        <label for="cashApp" class="form-check-label">Cash App</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="creditCard" name="paymentMethod" value="creditCard"
                                            class="form-check-input">
                                        <label for="creditCard" class="form-check-label">Credit Cards</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="payLater" name="paymentMethod" value="payLater"
                                            class="form-check-input">
                                        <label for="payLater" class="form-check-label">Pay Later</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="bankDeposit" name="paymentMethod" value="bankDeposit"
                                            class="form-check-input">
                                        <label for="bankDeposit" class="form-check-label">Bank Deposit (Chase Bank #
                                            597817520)</label>
                                    </div>

                                    <div id="bankDepositInfo" class="hidden mt-2">
                                        <form>
                                            <div class="input-group">

                                                <input type="text" id="depositConfirmationNumber"
                                                    name="depositConfirmationNumber"
                                                    placeholder="Enter Deposit Confirmation Number" class="form-control">

                                                <button class="btn btn-light-info text-info font-weight-medium"
                                                    type="button">Submit</button>

                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>

                            <h5 style="color:rgb(16, 16, 82)">Payment Location:</h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="paymentLocation">Note: Will the packages be paid for in:</label>
                                        <select id="paymentLocation" name="paymentLocation" class="form-control">
                                            <option value="USA">USA</option>
                                            <option value="DomRep">Dom Rep</option>
                                        </select>
                                    </div>
                                </div>
                                
                            </div>
                </div>

                </section>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        //Basic Example
        $("#example-basic").steps({
            headerTag: "h3",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            autoFocus: true,
        });

        // Basic Example with form
        var form = $("#example-form");
        form.validate({
            errorPlacement: function errorPlacement(error, element) {
                element.before(error);
            },
            rules: {
                confirm: {
                    equalTo: "#password",
                },
            },
        });
        form.children("div").steps({
            headerTag: "h3",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            onStepChanging: function(event, currentIndex, newIndex) {
                form.validate().settings.ignore = ":disabled,:hidden";
                return form.valid();
            },
            onFinishing: function(event, currentIndex) {
                form.validate().settings.ignore = ":disabled";
                return form.valid();
            },
            onFinished: function(event, currentIndex) {
                alert("Submitted!");
            },
        });

        // Advance Example

        var form = $("#example-advanced-form").show();

        form
            .steps({
                headerTag: "h3",
                bodyTag: "fieldset",
                transitionEffect: "slideLeft",
                onStepChanging: function(event, currentIndex, newIndex) {
                    // Allways allow previous action even if the current form is not valid!
                    if (currentIndex > newIndex) {
                        return true;
                    }
                    // Forbid next action on "Warning" step if the user is to young
                    if (newIndex === 3 && Number($("#age-2").val()) < 18) {
                        return false;
                    }
                    // Needed in some cases if the user went back (clean up)
                    if (currentIndex < newIndex) {
                        // To remove error styles
                        form.find(".body:eq(" + newIndex + ") label.error").remove();
                        form
                            .find(".body:eq(" + newIndex + ") .error")
                            .removeClass("error");
                    }
                    form.validate().settings.ignore = ":disabled,:hidden";
                    return form.valid();
                },
                onStepChanged: function(event, currentIndex, priorIndex) {
                    // Used to skip the "Warning" step if the user is old enough.
                    if (currentIndex === 2 && Number($("#age-2").val()) >= 18) {
                        form.steps("next");
                    }
                    // Used to skip the "Warning" step if the user is old enough and wants to the previous step.
                    if (currentIndex === 2 && priorIndex === 3) {
                        form.steps("previous");
                    }
                },
                onFinishing: function(event, currentIndex) {
                    form.validate().settings.ignore = ":disabled";
                    return form.valid();
                },
                onFinished: function(event, currentIndex) {
                    alert("Submitted!");
                },
            })
            .validate({
                errorPlacement: function errorPlacement(error, element) {
                    element.before(error);
                },
                rules: {
                    confirm: {
                        equalTo: "#password-2",
                    },
                },
            });

        // Dynamic Manipulation
        $("#example-manipulation").steps({
            headerTag: "h3",
            bodyTag: "section",
            enableAllSteps: true,
            enablePagination: false,
        });

        //Vertical Steps

        $("#example-vertical").steps({
            headerTag: "h3",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            stepsOrientation: "vertical",
        });

        //Custom design form example
        $(".tab-wizard").steps({
            headerTag: "h6",
            bodyTag: "section",
            transitionEffect: "fade",
            titleTemplate: '<span class="step">#index#</span> #title#',
            labels: {
                finish: "Submit",
            },
            onFinished: function(event, currentIndex) {
                swal(
                    "Form Submitted!",
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lorem erat eleifend ex semper, lobortis purus sed."
                );
            },
        });

        var form = $(".validation-wizard").show();

        $(".validation-wizard").steps({
                headerTag: "h6",
                bodyTag: "section",
                transitionEffect: "fade",
                titleTemplate: '<span class="step">#index#</span> #title#',
                labels: {
                    finish: "Submit",
                },
                onStepChanging: function(event, currentIndex, newIndex) {
                    return (
                        currentIndex > newIndex ||
                        (!(3 === newIndex && Number($("#age-2").val()) < 18) &&
                            (currentIndex < newIndex &&
                                (form.find(".body:eq(" + newIndex + ") label.error").remove(),
                                    form
                                    .find(".body:eq(" + newIndex + ") .error")
                                    .removeClass("error")),
                                (form.validate().settings.ignore = ":disabled,:hidden"),
                                form.valid()))
                    );
                },
                onFinishing: function(event, currentIndex) {
                    return (form.validate().settings.ignore = ":disabled"), form.valid();
                },
                onFinished: function(event, currentIndex) {
                    swal(
                        "Form Submitted!",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lorem erat eleifend ex semper, lobortis purus sed."
                    );
                },
            }),
            $(".validation-wizard").validate({
                ignore: "input[type=hidden]",
                errorClass: "text-danger",
                successClass: "text-success",
                highlight: function(element, errorClass) {
                    $(element).removeClass(errorClass);
                },
                unhighlight: function(element, errorClass) {
                    $(element).removeClass(errorClass);
                },
                errorPlacement: function(error, element) {
                    error.insertAfter(element);
                },
                rules: {
                    email: {
                        email: !0,
                    },
                },
            });
    </script>
    <script>
        $(document).ready(function() {
            $('input[name="paymentMethod"]').on('change', function() {

                if ($(this).val() === 'bankDeposit') {
                    $('#bankDepositInfo').show();
                } else {
                    $('#bankDepositInfo').hide();
                }

                if ($(this).val() === 'cash') {
                    $('#cashInfo').show();
                } else {
                    $('#cashInfo').hide();
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Function to update totals
            function updateTotals() {
                let totalPrice = 0.0;

                $('#itemList tbody tr').each(function() {
                    const price = parseFloat($(this).find('input[name="itemPrice[]"]').val()) || 0.0;
                    totalPrice += price;
                });

                $('#total').val(totalPrice.toFixed(2));
                updateGrandTotal();
            }

            function updateGrandTotal() {
                const total = parseFloat($('#total').val()) || 0.0;
                const discount = parseFloat($('#discount').val()) || 0.0;
                const grandTotal = total - discount;
                $('#grandTotal').val(grandTotal.toFixed(2));
            }



            // Add item button click event
            $('#addItem').click(function() {
                let newItem = `
            <tr class="item">
                <td>
                    <input type="number" name="quantity[]" class="form-control" required>
                </td>
                <td>
                    <input type="text" name="itemDescription[]" class="form-control" required>
                </td>
                <td>
                    <input type="text" name="itemPrice[]" class="form-control" required>
                </td>
                <td>
                    <button type="button" class="btn btn-danger removeItem">Remove</button>
                </td>
            </tr>`;
                $('#itemList tbody').append(newItem);
            });

            $(document).on('click', '.removeItem', function() {
                $(this).closest('tr').remove();
            });


            // Event listeners for input changes
            $(document).on('input', 'input[name="itemPrice[]"]', function() {
                updateTotals();
            });

            $(document).on('input', '#discount', function() {
                updateGrandTotal();
            });

            // Initial call to set totals
            updateTotals();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starp16/public_html/andy_delacruz/resources/views/user/pages/shipping/add_form.blade.php ENDPATH**/ ?>