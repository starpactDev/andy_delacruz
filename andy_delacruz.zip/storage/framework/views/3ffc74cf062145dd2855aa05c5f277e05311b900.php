<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-5 col-12 align-self-center">
            <h3 class="text-themecolor mb-0">Dashboard</h3>
            <ol class="breadcrumb mb-0 p-0 bg-transparent">
                <li class="breadcrumb-item">
                    <a href="javascript:void(0)">Home</a>
                </li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </div>
        <div class="col-md-7 col-12 align-self-center d-none d-md-block">
            
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-row">
                            <div
                                class="
                  round round-lg
                  text-white
                  d-flex
                  align-items-center
                  justify-content-center
                  rounded-circle
                  bg-info
                ">
                                <i data-feather="credit-card" class="fill-white feather-lg"></i>
                            </div>
                            <div class="ms-2 align-self-center">
                                <h3 class="mb-0">Manage Client</h3>
                                <h6 class="text-muted mb-0"></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-row">
                            <div
                                class="
                  round round-lg
                  text-white
                  d-flex
                  align-items-center
                  justify-content-center
                  rounded-circle
                  bg-warning
                ">
                                <i data-feather="monitor" class="fill-white feather-lg"></i>
                            </div>
                            <div class="ms-2 align-self-center">
                                <h3 class="mb-0">Projects Ongoing</h3>
                                <h6 class="text-muted mb-0">0</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-row">
                            <div
                                class="
                  round round-lg
                  text-white
                  d-flex
                  align-items-center
                  justify-content-center
                  rounded-circle
                  bg-primary
                ">
                                <i data-feather="shopping-bag" class="fill-white feather-lg"></i>
                            </div>
                            <div class="ms-2 align-self-center">
                                <h3 class="mb-0">Complete Projects</h3>
                                <h6 class="text-muted mb-0">0</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->

            <!-- Column -->
        </div>
        <div class="row">
            <div class="col-lg-12 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body">
                        <div class="d-md-flex no-block">
                            <h4 class="card-title">Projects Overview</h4>

                        </div>
                        <div class="month-table">
                            <div class="table-responsive mt-3">
                                <table class="table stylish-table v-middle mb-0 no-wrap">
                                    <thead>
                                        <tr>
                                            <th class="border-0 text-muted fw-normal">
                                                Name
                                            </th>


                                            <th class="border-0 text-muted fw-normal">
                                                Contract Value in Lakh(Rs.)
                                            </th>
                                            <th class="border-0 text-muted fw-normal">
                                                Date of Award of Contract
                                            </th>
                                            <th class="border-0 text-muted fw-normal">
                                                Date of Completion
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td>
                                                <h6 class="font-weight-medium mb-0">
                                                    Kishangarh Ajmer Beawar Road Project (NH - 8)
                                                </h6>

                                            </td>
                                            <td> <span class="badge bg-success px-2 py-1">431.78</span></td>
                                            <td> <span class="badge bg-warning px-2 py-1">29.05.2010</span></td>
                                            <td> <span class="badge bg-info px-2 py-1">28.02.2013</span></td>
                                        </tr>
                                        <tr>

                                            <td>
                                                <h6 class="font-weight-medium mb-0">
                                                    Construction of Rail Over Bridge
                                                </h6>

                                            </td>
                                            <td> <span class="badge bg-success px-2 py-1">1330.52 </span></td>
                                            <td> <span class="badge bg-warning px-2 py-1">19.09.2010</span></td>
                                            <td> <span class="badge bg-info px-2 py-1">30.09.2012</span></td>
                                        </tr>
                                        <tr>

                                            <td>
                                                <h6 class="font-weight-medium mb-0">
                                                    Ready Mix Concrete Supply
                                                </h6>

                                            </td>
                                            <td> <span class="badge bg-success px-2 py-1">918.75 </span></td>
                                            <td> <span class="badge bg-warning px-2 py-1">11.02.2011</span></td>
                                            <td> <span class="badge bg-primary px-2 py-1">Work In Progress</span></td>
                                        </tr>
                                        <tr>

                                            <td>
                                                <h6 class="font-weight-medium mb-0">
                                                    Construction of High level Bridge
                                                </h6>

                                            </td>
                                            <td> <span class="badge bg-success px-2 py-1">389.30 </span></td>
                                            <td> <span class="badge bg-warning px-2 py-1">08.04.2013</span></td>
                                            <td> <span class="badge bg-danger px-2 py-1">Incomplete</span></td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row el-element-overlay">

            <div class="col-lg-12 d-flex align-items-stretch m-5">
                <div class="row">
                    <div class="d-md-flex no-block">
                        <h4 class="card-title">Projects Gallery</h4>

                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img1.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img1.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img2.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img2.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img3.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img3.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img4.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img4.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img3.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img3.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img5.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img5.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img6.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img6.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="el-card-item pb-3">
                        <div
                            class="
                      el-card-avatar
                      mb-3
                      el-overlay-1
                      w-100
                      overflow-hidden
                      position-relative
                      text-center
                    ">
                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/big/img1.jpeg"
                                class="d-block position-relative w-100" alt="user" />
                            <div class="el-overlay w-100 overflow-hidden">
                                <ul
                                    class="
                          list-style-none
                          el-info
                          text-white text-uppercase
                          d-inline-block
                          p-0
                        ">
                                    <li class="el-item d-inline-block my-0 mx-1">
                                        <a class="
                              btn
                              default
                              btn-outline
                              image-popup-vertical-fit
                              el-link
                              text-white
                              border-white
                            "
                                            href="<?php echo e(url('/')); ?>/admin/assets/images/big/img1.jpeg"><i
                                                class="icon-magnifier"></i></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="el-card-content text-center">
                            <h4 class="mb-0">Project title</h4>
                            <span class="text-muted">subtitle of project</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rn_infra\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>