<?php $__env->startSection('content'); ?>
<style>
       .action-buttons {
         width: 70px;
       height: 70px;
    display: flex;
    flex-direction: column;
    align-items: center; /* This centers the buttons */
}

.action-buttons button {
    margin-bottom: 5px; /* Optional: Add space between buttons */
}
</style>
    <div class="row page-titles">
        <div class="col-md-5 col-12 align-self-center">
            <h3 class="text-themecolor mb-0">Merchandise Suppiers List</h3>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="javascript:void(0)">Home</a>
                </li>
                <li class="breadcrumb-item active">Merchandise Suppiers List</li>
            </ol>
        </div>

    </div>

    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <div class="row">
            <!-- Column -->
            <div class="col-lg-12 col-xl-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex no-block align-items-center mb-4">
                            <h4 class="card-title">Merchandise Suppiers</h4>
                            <div class="ms-auto">
                                <div class="btn-group">
                                    <button type="button"
                                        class="
                          btn btn-light-primary
                          text-primary
                          font-weight-medium
                          rounded-pill
                          px-4
                        "
                                        data-bs-toggle="modal" data-bs-target="#createmodel">
                                        Create New Account
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Suppier Id</th>
                                        <th>Full Name</th>
                                        <th>E-mail</th>
                                        <th>Phone Number</th>
                                        <th>Address</th>
                                        <th>Sell Products</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>2001</td>
                                        <td>Michael Brown</td>
                                        <td>michaelbrown@example.com</td>
                                        <td>+1 555-111-2222</td>
                                        <td>1234 Elm Street, Austin, TX 78701</td>
                                        <td>
                                            <span class="badge bg-primary px-2 py-1 m-1">Laptops</span>

                                        </td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2002</td>
                                        <td>Susan Taylor</td>
                                        <td>susantaylor@example.com</td>
                                        <td>+1 555-333-4444</td>
                                        <td>5678 Oak Lane, San Francisco, CA 94107</td>
                                        <td>
                                            <span class="badge bg-primary px-2 py-1 m-1">Mobile Phones</span>

                                        </td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2003</td>
                                        <td>Robert Johnson</td>
                                        <td>robertjohnson@example.com</td>
                                        <td>+1 555-555-6666</td>
                                        <td>9101 Pine Road, Miami, FL 33101</td>
                                        <td>
                                            <span class="badge bg-primary px-2 py-1 m-1">Cameras</span>

                                        </td>
                                        <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2004</td>
                                        <td>Emily Davis</td>
                                        <td>emilydavis@example.com</td>
                                        <td>+1 555-777-8888</td>
                                        <td>1123 Maple Avenue, New York, NY 10001</td>
                                        <td>
                                            <span class="badge bg-primary px-2 py-1 m-1">Printers</span>

                                        </td>
                                        <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2005</td>
                                        <td>David Lee</td>
                                        <td>davidlee@example.com</td>
                                        <td>+1 555-999-0000</td>
                                        <td>1415 Cedar Street, Chicago, IL 60601</td>
                                        <td>
                                            <span class="badge bg-primary px-2 py-1 m-1">Headphones</span>
                                           
                                        </td>
                                        <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <!-- Create Modal -->
            <div class="modal fade" id="createmodel" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form>
                            <div class="modal-header d-flex align-items-center">
                                <h5 class="modal-title" id="createModalLabel">
                                    <i class="ti-marker-alt me-2"></i> Create New Supplier Account
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter First Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Last Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="mail" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="email" class="form-control" placeholder="Enter E-mail Address Here"
                                        aria-label="email" />
                                </div>

                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="phone" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Phone Number Here"
                                        aria-label="no" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map-pin" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Street Address Here"
                                        aria-label="address" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="home" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter City Here"
                                        aria-label="city" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter State Here"
                                        aria-label="state" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="hash" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter ZIP Code Here"
                                        aria-label="zip" />
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-info">
                                            <i data-feather="user" class="feather-sm fil-white"></i>
                                        </button>
                                    </div>
                                    <select class="form-control" aria-label="Role Selection" >
                                        <option selected>Select Sell products</option>
                                        <optgroup label="Products">
                                            <option value="Laptops">Laptops</option>
                                            <option value="Monitors">Monitors</option>
                                            <option value="Mobile Phones">Mobile Phones</option>
                                            <option value="Tablets">Tablets</option>
                                            <option value="Cameras">Cameras</option>
                                            <option value="Lenses">Lenses</option>
                                            <option value="Printers">Printers</option>
                                            <option value="Scanners">Scanners</option>
                                            <option value="Headphones">Headphones</option>
                                            <option value="Speakers">Speakers</option>
                                        </optgroup>
                                    </select>
                                </div>
                              <!-- Password Input Field -->
                              <div class="input-group mb-3">
                                <button type="button" class="btn btn-info">
                                    <i data-feather="lock" class="feather-sm fil-white"></i>
                                </button>
                                <input type="password" class="form-control" placeholder="Enter Password Here"
                                    aria-label="password" />
                            </div>

                            <!-- Confirm Password Input Field -->
                            <div class="input-group mb-3">
                                <button type="button" class="btn btn-info">
                                    <i data-feather="lock" class="feather-sm fil-white"></i>
                                </button>
                                <input type="password" class="form-control" placeholder="Confirm Password Here"
                                    aria-label="confirm-password" />
                            </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button"
                                    class="
                      btn btn-light-danger
                      text-danger
                      font-weight-medium
                      rounded-pill
                      px-4
                    "
                                    data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-success rounded-pill px-4">
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End PAge Content -->
        <!-- -------------------------------------------------------------- -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starp16/public_html/andy_delacruz/resources/views/user/pages/supplier/index.blade.php ENDPATH**/ ?>