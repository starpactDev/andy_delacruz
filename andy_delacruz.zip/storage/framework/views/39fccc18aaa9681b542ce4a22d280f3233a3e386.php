<?php $__env->startSection('content'); ?>
    <?php
        $isClientListOff = \Illuminate\Support\Facades\DB::table('manage_permission_for_managers')
            ->where('key', 'docs_list')
            ->where('value', 'off')

            ->exists();
            $auth = Auth::user()->type;

    ?>
    <div class="container-fluid">
        <?php if($auth == 0 || ($auth == 2 && !$isClientListOff)): ?>
            <div class="font-weight-medium shadow-none position-relative overflow-hidden mb-7">
                <div class="card-body px-0">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="font-weight-medium  mb-0">IDENTIFICATION UPLOADED BY USA DRIVER</h4>
                            <p class="card-subtitle mb-3">
                                VALID FORMS OF IDENTIFICATION:
                            </p>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row el-element-overlay">
                <?php if($senderIdentityCard): ?>
                    <?php if($senderIdentityCard->id_front): ?>
                        <div class="col-md-4">
                            <div class="card overflow-hidden">
                                <div class="el-card-item pb-3">
                                    <div
                                        class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                        <a class="image-popup-vertical-fit"
                                            href="<?php echo e(url('uploads/identity_cards/' . $senderIdentityCard->id_front)); ?>">
                                            <img src="<?php echo e(url('uploads/identity_cards/' . $senderIdentityCard->id_front)); ?>"
                                                class="d-block position-relative w-100" alt="user">
                                        </a>
                                    </div>
                                    <div class="el-card-content text-center">
                                        <h4 class="card-title">ID FRONT</h4>
                                        <p class="card-subtitle">U.S. DRIVER'S LICENSE OR ID (FRONT)</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endif; ?>

                    <?php if($senderIdentityCard->id_back): ?>
                        <div class="col-md-4">
                            <div class="card overflow-hidden">
                                <div class="el-card-item pb-3">
                                    <div
                                        class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                        <a class="image-popup-vertical-fit"
                                            href="<?php echo e(url('uploads/identity_cards/' . $senderIdentityCard->id_back)); ?>">
                                            <img src="<?php echo e(url('uploads/identity_cards/' . $senderIdentityCard->id_back)); ?>"
                                                class="d-block position-relative w-100" alt="user">
                                        </a>
                                    </div>
                                    <div class="el-card-content text-center">
                                        <h4 class="card-title">ID BACK</h4>
                                        <p class="card-subtitle">U.S. DRIVER'S LICENSE OR ID (BACK)</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <h5 class="text-center" style="color: red; font-size:24px"> Nothing Uploaded in Sender Identity</h5>
                <?php endif; ?>


            </div>
            <div class="font-weight-medium shadow-none position-relative overflow-hidden mb-7">
                <div class="card-body px-0">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="font-weight-medium  mb-0">PACKAGES</h4>
                            <p class="card-subtitle mb-3">
                                PHOTOS OF PACKAGES TO BE SHIPPED:
                            </p>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row el-element-overlay">
                <?php if($packageImages): ?>
                    <?php if($packageImages->isNotEmpty()): ?>
                        <?php $__currentLoopData = $packageImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card overflow-hidden">
                                    <div class="el-card-item pb-3">
                                        <div
                                            class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                            <a class="image-popup-vertical-fit" href="<?php echo e(url($packageImage->image)); ?>">
                                                <img src="<?php echo e(url($packageImage->image)); ?>"
                                                    class="d-block position-relative w-100" style="height:300px"
                                                    alt="user">
                                            </a>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php else: ?>
                    <h5 class="text-center" style="color: red; font-size:24px"> Nothing Uploaded in Packages to be shipped
                    </h5>
                <?php endif; ?>


            </div>

            <div class="font-weight-medium shadow-none position-relative overflow-hidden mb-7">
                <div class="card-body px-0">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="font-weight-medium  mb-0">IDENTIFICATION UPLOADED BY RD DRIVER</h4>
                            <p class="card-subtitle mb-3">
                                VALID FORMS OF IDENTIFICATION:
                            </p>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row el-element-overlay">
                <?php if($receiverIdentityCard): ?>
                    <?php if($receiverIdentityCard->id_front): ?>
                        <div class="col-md-4">
                            <div class="card overflow-hidden">
                                <div class="el-card-item pb-3">
                                    <div
                                        class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                        <a class="image-popup-vertical-fit"
                                            href="<?php echo e(url('uploads/identity_cards/' . $receiverIdentityCard->id_front)); ?>">
                                            <img src="<?php echo e(url('uploads/identity_cards/' . $receiverIdentityCard->id_front)); ?>"
                                                class="d-block position-relative w-100" alt="user">
                                        </a>
                                    </div>
                                    <div class="el-card-content text-center">
                                        <h4 class="card-title">ID FRONT</h4>
                                        <p class="card-subtitle">DOM REP DRIVER LICENSE OR ELECTORAL ID (FRONT)</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endif; ?>

                    <?php if($receiverIdentityCard->id_back): ?>
                        <div class="col-md-4">
                            <div class="card overflow-hidden">
                                <div class="el-card-item pb-3">
                                    <div
                                        class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                        <a class="image-popup-vertical-fit"
                                            href="<?php echo e(url('uploads/identity_cards/' . $receiverIdentityCard->id_back)); ?>">
                                            <img src="<?php echo e(url('uploads/identity_cards/' . $receiverIdentityCard->id_back)); ?>"
                                                class="d-block position-relative w-100" alt="user">
                                        </a>
                                    </div>
                                    <div class="el-card-content text-center">
                                        <h4 class="card-title">ID BACK</h4>
                                        <p class="card-subtitle">DOM REP DRIVER LICENSE OR ELECTORAL ID (BACK)</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <h5 class="text-center" style="color: red; font-size:24px"> Nothing Uploaded in Receivers Identity</h5>
                <?php endif; ?>


            </div>
        <?php endif; ?>
        <div class="font-weight-medium shadow-none position-relative overflow-hidden mb-7">
            <div class="card-body px-0">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="font-weight-medium  mb-0">PACKAGES</h4>
                        <p class="card-subtitle mb-3">
                            PHOTOS OF DELIVERED PACKAGES:
                        </p>
                    </div>

                </div>
            </div>
        </div>

        <div class="row el-element-overlay">
            <?php if($receiverPackageImages): ?>
                <?php if($receiverPackageImages->isNotEmpty()): ?>
                    <?php $__currentLoopData = $receiverPackageImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="card overflow-hidden">
                                <div class="el-card-item pb-3">
                                    <div
                                        class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                        <a class="image-popup-vertical-fit" href="<?php echo e(url($packageImage->image)); ?>">
                                            <img src="<?php echo e(url($packageImage->image)); ?>"
                                                class="d-block position-relative w-100" style="height:300px" alt="user">
                                        </a>
                                    </div>

                                </div>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php else: ?>
                <h5 class="text-center" style="color: red; font-size:24px"> Nothing Uploaded in packages that need to be
                    delivered</h5>
            <?php endif; ?>


        </div>


        <div class="font-weight-medium shadow-none position-relative overflow-hidden mb-7">
            <div class="card-body px-0">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="font-weight-medium  mb-5">SIGNATURES</h4>

                    </div>

                </div>
            </div>
        </div>

        <div class="row el-element-overlay">
            <?php if($auth == 0 || ($auth == 2 && !$isClientListOff)): ?>
                <?php if($senderSignature): ?>
                    <?php if($senderSignature->signature_image): ?>
                        <div class="col-md-4">
                            <div class="card overflow-hidden">
                                <div class="el-card-item pb-3">
                                    <div
                                        class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                        <a class="image-popup-vertical-fit"
                                            href="<?php echo e(url('sender_signatures/' . $senderSignature->signature_image)); ?>">
                                            <img src="<?php echo e(url('sender_signatures/' . $senderSignature->signature_image)); ?>"
                                                class="d-block position-relative w-100" alt="user">
                                        </a>
                                    </div>
                                    <div class="el-card-content text-center">
                                        <h4 class="card-title">Sender Signature</h4>

                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <h5 class="text-center" style="color: red; font-size:24px"> Sender Signature not Uploaded</h5>
                <?php endif; ?>
            <?php endif; ?>
            <?php if($receiverSignature): ?>
                <?php if($receiverSignature->signature_image): ?>
                    <div class="col-md-4">
                        <div class="card overflow-hidden">
                            <div class="el-card-item pb-3">
                                <div
                                    class="
                el-card-avatar
                mb-3
                el-overlay-1
                w-100
                overflow-hidden
                position-relative
                text-center
              ">
                                    <a class="image-popup-vertical-fit"
                                        href="<?php echo e(url('sender_signatures/' . $receiverSignature->signature_image)); ?>">
                                        <img src="<?php echo e(url('sender_signatures/' . $receiverSignature->signature_image)); ?>"
                                            class="d-block position-relative w-100" alt="user">
                                    </a>
                                </div>
                                <div class="el-card-content text-center">
                                    <h4 class="card-title">Receiver Signature</h4>

                                </div>
                            </div>
                        </div>

                    </div>
                <?php endif; ?>
            <?php else: ?>
                <h5 class="text-center" style="color: red; font-size:24px"> Receiver Signature not Uploaded</h5>
            <?php endif; ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andy\resources\views/user/pages/container/packages_info.blade.php ENDPATH**/ ?>