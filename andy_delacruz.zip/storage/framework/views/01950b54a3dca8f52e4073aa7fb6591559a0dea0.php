<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
      <!-- User profile -->
      <div
        class="user-profile position-relative"
        style="
          background: url('admin/assets/images/background/user_bg1.jpeg')
            no-repeat;
        "
      >
        <!-- User profile image -->
        <div class="profile-img">
          <img
            src="<?php echo e(url('/')); ?>/admin/assets/images/users/profile.png"
            alt="user"
            class="w-100"
          />
        </div>
        <!-- User profile text-->
        <div class="profile-text pt-1 dropdown">
          <a
            href="#"
            class="
              dropdown-toggle
              u-dropdown
              w-100
              text-white
              d-block
              position-relative
            "
            id="dropdownMenuLink"
            data-bs-toggle="dropdown"
            aria-expanded="false"
            ><?php echo e(Auth::user()->name); ?></a
          >
          <div
            class="dropdown-menu animated flipInY"
            aria-labelledby="dropdownMenuLink"
          >
            <a class="dropdown-item" href="#"
              ><i
                data-feather="user"
                class="feather-sm text-info me-1 ms-1"
              ></i>
              My Profile</a
            >


            <div class="dropdown-divider"></div>

            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('admin.admin_logout')); ?>" onclick="confirmLogout(event)">
                <i data-feather="log-out" class="feather-sm text-danger me-1 ms-1"></i>
                Logout
              </a>
            <div class="dropdown-divider"></div>

          </div>
        </div>
      </div>
      <!-- End User profile text-->
      <!-- Sidebar navigation-->
      <nav class="sidebar-nav">
        <ul id="sidebarnav">
          <li class="nav-small-cap">
            <i class="mdi mdi-dots-horizontal"></i>
            <span class="hide-menu">HOME</span>
          </li>

          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="<?php echo e(route('admin.dashboard')); ?>"
              aria-expanded="false"
              ><i class="mdi mdi-view-dashboard"></i>
              <span class="hide-menu">Dashboard</span></a
            >
          </li>
          <li class="nav-small-cap">
            <i class="mdi mdi-dots-horizontal"></i>
            <span class="hide-menu">Projects</span>
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="<?php echo e(route('admin.complete_projects')); ?>"
              aria-expanded="false"
              ><i class="mdi mdi-checkbox-marked-circle-outline"></i>
              <span class="hide-menu">Complete Projects</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="<?php echo e(route('admin.ongoing_projects')); ?>"
              aria-expanded="false"
              ><i class="mdi mdi-timer-sand"></i>
              <span class="hide-menu">Ongoing Projects</span></a
            >
          </li>
          <li class="sidebar-item">
            <a
              class="sidebar-link waves-effect waves-dark sidebar-link"
              href="<?php echo e(route('admin.add_projects')); ?>"
              aria-expanded="false"
              ><i class="mdi mdi-plus-box-outline"></i></i
              ><span class="hide-menu">Add Projects</span></a
            >
          </li>









        </ul>
      </nav>
      <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
    <!-- Bottom points-->
    <div class="sidebar-footer">
      <!-- item-->
      
      <!-- item-->

      <!-- item-->
      <a
       href="<?php echo e(route('admin.admin_logout')); ?>" onclick="confirmLogout(event)"
        class="link"

        title="Logout"
        ><i class="mdi mdi-power"></i
      ></a>
    </div>
    <!-- End Bottom points-->
  </aside>
<?php /**PATH C:\xampp\htdocs\rn_infra\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>