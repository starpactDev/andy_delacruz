<?php $__env->startSection('content'); ?>
    <style>
        .title {
            color: rgb(10, 78, 99);
        }

        .btn {
            margin-right: 5px;
        }

        .top-right-buttons {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .top-right-buttons button {
            margin-left: 10px;
        }

        .signature-row {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .signature-container {
            width: 45%;
            /* Adjust the width as needed */
        }

        .signature-line {
            border-bottom: 1px solid #000;
            width: 100%;
            height: 50px;
            /* Adjust the height as needed */
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .signature-image {
            max-height: 100%;
            /* Ensure the image fits within the line */
            max-width: 100%;
        }

        .signature-name {
            text-align: center;
            margin-top: 5px;
            font-size: 16px;
        }

        .important-notes-list-1 li {
            margin-bottom: 10px;
            font-size: 12.5px;
        }

        .font-weight-bold {
            font-weight: bold;
        }

        ul {
            color: #000 !important;
        }
    </style>
    <!-- -------------------------------------------------------------- -->
    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="top-right-buttons">
                    <?php if($orderDetails->label_count): ?>
                    <?php
                    $currentUser = auth()->user();
                    $userDriverInfo = $currentUser->driverInfo; // Assuming there's a relation defined between User and UserDriverInfo
                ?>
                    <?php if(!($currentUser->type == 1 && optional($userDriverInfo)->team == 'Dominican Team')): ?>


                        <button class="btn btn-warning" onclick="redirectToShipping('<?php echo e($orderDetails->order_number); ?>')">
                            <i class="fas fa-truck"></i> Proceed to Shipping Label
                        </button>
                    <?php endif; ?>
                    <?php endif; ?>
                    <button class="btn btn-primary nav-item dropdown">
                        <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-paper-plane"></i> Share Invoice
                        </a>
                        <div class=" dropdown-menu dropdown-menu-end user-dd animated flipInY">
                            <a class="dropdown-item" id="gmailShareButton" href="#" target="_blank"><i
                                    class="fas fa-envelope text-primary me-1 ms-1" style="font-size: 18px;"></i> Via Email
                            </a>




                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" data-bs-toggle="tooltip" id="whatsappShareButton"
                                data-bs-placement="top"><i class="fab fa-whatsapp feather-sm text-success me-1 ms-1"
                                    style="font-size: 18px;"></i>
                                Via Whatsapp</a>

                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" id="smsShareButton"><i class="fas fa-comment-dots text-info me-1 ms-1"
                                    style="font-size: 18px;"></i>
                                Via SMS</a>
                        </div>
                    </button>



                    <button class="btn btn-info" onclick="redirectToInvoices('<?php echo e($orderDetails->order_number); ?>')">
                        <i class="fas fa-print"></i> Proceed to Print or Download
                    </button>


                    
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-body printableArea">
                    <h3><b>ORDER NUMBER</b> <span class="pull-right"> # <?php echo e($orderDetails->order_number); ?></span></h3>
                    <hr />
                    <div class="row">
                        <div class="col-md-12">
                            <div class="pull-right ">
                                <div class="invoice-logo">
                                    <!-- logo started -->
                                    <div class="logo">
                                        <img src="<?php echo e(url('/')); ?>/admin/assets/images/andy.png" alt="logo" />
                                    </div>
                                    <!-- logo ended -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="invoice-number mb-30">
                                <h4 class="inv-title-1">Address 1</h4>
                                <h6 class="name"><i class="fa fa-map-marker" style="margin-right: 5px;"></i>3115
                                    WASHINGTON STREET</h6>
                                <p class="invo-addr-1 mt-10">
                                    ROXBURY, MA. 02130 <br />
                                    617-477-9072 <br />
                                    781-439-2046<br />
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="invoice-number mb-30">
                                <h4 class="inv-title-1">Address 2</h4>
                                <h6 class="name"><i class="fa fa-map-marker" style="margin-right: 5px;"></i>57 CHASE
                                    STREET</h6>
                                <p class="invo-addr-1 mt-10">
                                    METHUEN, MA 01844 <br />
                                    978-258-0238 <br />
                                    978-258-0154<br />
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="invoice-number mb-30">
                                <h4 class="inv-title-1">Address 3</h4>
                                <h6 class="name"><i class="fa fa-map-marker" style="margin-right: 5px;"></i>BANI,
                                    DOMINICAN REPUBLIC</h6>
                                <p class="invo-addr-1 mt-10">
                                    ANA PRAVIA STREET # 99 PERAVIA <br />
                                    809-522-3648 <br />
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <address>
                                <h4 class="fw-bold" style="color:#4d545a">Invoice:</h4>
                                <p>
                                    <b>Order Number #: <br></b><?php echo e($orderDetails->order_number); ?><br />
                                    <b>Issue Date:
                                    </b><?php echo e(\Carbon\Carbon::parse($orderDetails->issue_date)->format('d M Y')); ?> <br />

                                    <b>Container ID: </b><?php echo e($orderDetails->container_number); ?> <br />
                                    <b>Driver Name: </b><?php echo e($orderDetails->driver_pickup_name); ?>

                                </p>
                            </address>
                        </div>
                    </div>
                    <hr />
                    <div class="row  d-flex justify-content-between">
                        <div class="col-md-6" style=" padding-right: 10px;">
                            <address>
                                <h4 class="fw-bold">Sender:</h4>
                                <h5><?php echo e($orderDetails->sender->first_name); ?> <?php echo e($orderDetails->sender->last_name); ?></h5>
                                <p class="text-muted">
                                    <b>Email:&nbsp;</b><?php echo e($orderDetails->sender->email); ?> <br />
                                    <b>Tel:&nbsp;</b><?php echo e($orderDetails->sender->telephone); ?> <br />
                                    <b>Cell:&nbsp;</b><?php echo e($orderDetails->sender->cell); ?> <br />
                                    <b>Address:&nbsp;</b><?php echo e($orderDetails->sender->street_address); ?>

                                    <?php echo e($orderDetails->sender->apt); ?> <br />
                                    <b>City:&nbsp;</b><?php echo e($orderDetails->sender->city); ?> <br />
                                    <b>State:&nbsp;</b><?php echo e($orderDetails->sender->state); ?> <br />
                                    <b>Zip:&nbsp;</b><?php echo e($orderDetails->sender->zip); ?> <br />
                                </p>
                            </address>
                        </div>
                        <div class="col-md-6 " style=" padding-right: 10px;">
                            <address>
                                <h4 class="fw-bold">Receiver:</h4>
                                <h5><?php echo e($orderDetails->receiver->first_name); ?> <?php echo e($orderDetails->receiver->last_name); ?>

                                </h5>
                                <p class="text-muted">
                                    <b>Email:&nbsp;</b><?php echo e($orderDetails->receiver->email); ?> <br />
                                    <b>Tel:&nbsp;</b><?php echo e($orderDetails->receiver->telephone); ?> <br />
                                    <b>Cell:&nbsp;</b><?php echo e($orderDetails->receiver->cell); ?> <br />
                                    <b>WhatsApp:&nbsp;</b><?php echo e($orderDetails->receiver->whatsapp); ?> <br />
                                    <b>Address:&nbsp;</b><?php echo e($orderDetails->receiver->address); ?> <br />
                                    <b>Neighbourhood:&nbsp;</b><?php echo e($orderDetails->receiver->neighborhood); ?> <br />
                                    <b>City:&nbsp;</b><?php echo e($orderDetails->receiver->city); ?> <br />
                                    <b>Province:&nbsp;</b><?php echo e($orderDetails->receiver->province); ?> <br />
                                </p>
                            </address>
                        </div>
                        
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive m-t-40" style="clear: both">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th>Items</th>
                                            <th class="text-end">QTY</th>
                                            <th class="text-end">Price</th>

                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $orderDetails->itemDescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $itemDescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($itemDescription->item_des); ?></td>
                                                <td class="text-end"><?php echo e($itemDescription->quantity); ?></td>
                                                <td class="text-end">$<?php echo e(number_format($itemDescription->price, 2)); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="pull-right m-t-30 text-end">
                                <table class="table invoice-summary-table">
                                    <tr class="sub-total-row">
                                        <td><b>Sub - Total:</b></td>
                                        <td>$<?php echo e($orderDetails->total); ?></td>
                                    </tr>


                                    <tr class="sub-total-row">
                                        <td><b>Discount:</b></td>
                                        <td>$<?php echo e($orderDetails->discount ?? '0.00'); ?> </td>
                                    </tr>
                                    <tr class="sub-total-row">
                                        <td>

                                        </td>
                                        <td>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h3><b>Grand Total:</b></h3>
                                        </td>
                                        <td>
                                            <h3>$<?php echo e($orderDetails->grand_total_amount); ?></h3>
                                        </td>
                                    </tr>

                                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><b>Deposit <?php echo e($key + 1); ?>:</b></td>
                                            <td>
                                                <h3 style="color: rgb(37, 165, 37)">$<?php echo e($deposit['amount']); ?></h3>
                                                <br>
                                                <?php if($deposit['method'] == 'cash'): ?>
                                                    <p style="color: rgb(35, 9, 77); font-weight:600">Cash (US)</p>
                                                    <?php else: ?>
                                                    <p style="color: rgb(35, 9, 77); font-weight:600">

                                                        <?php echo e(ucfirst($deposit['method'])); ?></p>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><b> Total Value Paid:</b></td>
                                        <td>
                                            <h3 style="color: green">$<?php echo e($orderDetails->amount_paid); ?></h3>
                                        </td>
                                    </tr>
                                    <?php
                                        $total = $orderDetails->grand_total_amount;
                                        $paid = $orderDetails->amount_paid;
                                        $balance = $total - $paid;
                                    ?>
                                    <tr class="sub-total-row">
                                        <td><b>Balance Due :</b></td>
                                        <td>
                                            <h3 style="color: red">$<?php echo e($balance); ?></h3>
                                        </td>
                                    </tr>
                                    
                                    <tr class="sub-total-row">
                                        <td><b>Payment Location :</b></td>
                                        <td><b><?php echo e($orderDetails->payment_location); ?></b></td>
                                    </tr>

                                    <tr class="sub-total-row">
                                        <td><b>Total packages to be delivered :</b></td>
                                        <td><b><?php echo e($orderDetails->total_no_packages); ?></b></td>
                                    </tr>

                                </table>
                            </div>
                            <div class="clearfix"></div>

                        </div>
                    </div>
                    <hr>
                    <hr>
                    <div class="row mb-4 mt-4">
                        <div class="col-sm-12">
                            <div class="important-note" style="margin-top:35px">
                                <h5 class="inv-title-1 text-center" style="color:red!important">COMPANY POLICY</h5>
                                <ul class="important-notes-list-1">
                                    <li> WE ARE NOT RESPONSIBLE FOR GOODS FOR DAMAGE FROM FIRE OR FLOODS.</li>
                                    <li> We thank you if you save your invoice for future claims or inconveniences.</li>
                                    <li>If you pay immediately, you will be one of the first customers to receive your
                                        merchandise.</li>
                                    <li> We pay 5% on the declared value</li>
                                    <li> Any UNPAID package that remains in our warehouse in the Dominican Republic for
                                        more than 15 days will be auctioned and the resources obtained through the
                                        auction will be
                                        used to cover the costs of your package.</li>
                                </ul>
                                <h5 class="font-weight-bold" style="font-size:16px">Contrato/Contract</h5>
                                <ul class="important-notes-list-1">
                                    <li><strong>Receiving Cargo:</strong>
                                        <ul>
                                            <li>At the time of receiving cargo, the consignee must check it to make sure
                                                that everything is okay. He or she must sign a document and, as soon as
                                                the consignee signs such document, neither the exporter nor the
                                                consignee will have any rights to complain for lost or damaged items.
                                            </li>
                                            <li>Any cargo with balance left more than fifteen days in our warehouse will
                                                be charged a 5% of the freight charge every fifteen days. If the company
                                                does not receive any payments during the next three months, the customer
                                                will lose the cargo, and the company will reserve the rights to do
                                                anything with it.</li>
                                            <li>The company is not responsible for any illegal items contained in the
                                                packages.</li>
                                        </ul>
                                    </li>
                                    <li><strong>NOTE:</strong> The company agrees to pay for the articles in case of
                                        loss or irreparable damage, as follows:
                                        <ul>
                                            <li>To new articles, a 10% of the value of the freight is charged as an
                                                additional insurance policy. In case of loss or irreparable damage, the
                                                client will receive payment of the total value of the good in the market
                                                as new. The client must show the original receipt from the store where
                                                it was purchased.</li>
                                            <li>To used articles, a 5% of the value of the freight is charged as an
                                                additional insurance policy. In case of loss or irreparable damage, the
                                                client will receive payment of 25% of the value of the article in the
                                                market.</li>
                                            <li>In case of loss, the client will only receive payment for values
                                                declared on this invoice.</li>
                                        </ul>
                                    </li>
                                    <li><strong>CLAIMS:</strong>
                                        <ul>
                                            <li>We only accept claims at the time of receiving the cargo. After items
                                                have been received, in case damage has occurred it will only be replaced
                                                if such damage cannot be repaired. The company will not replace the item
                                                for cash, it will only be replaced with one similar if it cannot be
                                                repaired.</li>
                                        </ul>
                                    </li>
                                    <li><strong>BOXES OF PERSONAL BELONGINGS:</strong>
                                        <ul>
                                            <li>Must be 18”X18”X28”. In these boxes, new articles are not accepted
                                                without being declared; articles by dozen are not accepted nor for
                                                commercial use.</li>
                                            <li>In case of loss of a box of personal belongings, the company will pay a
                                                maximum of $100.00 dollars per box after an investigation has been made,
                                                and a credit will be given for another box of the same dimensions
                                                (18”X18”X28”).</li>
                                            <li>The same clauses apply to boxes of used clothes. Jewelry or cell phones
                                                are not accepted, and any article whose value exceeds $30.00 must be
                                                declared.</li>
                                        </ul>
                                    </li>
                                    <li><strong>CLAIMS FOR BROKEN LAMPS OR GLASSES:</strong>
                                        <ul>
                                            <li>The company is not responsible for lamps or glasses packed by anyone
                                                other than this company’s employees; it will only pay a maximum of
                                                $100.00 for irreparable broken lamps or glasses.</li>
                                        </ul>
                                    </li>
                                    <li><strong>DELIVERY OF BOXES:</strong>
                                        <ul>
                                            <li>The company is only responsible for new articles declared in the
                                                invoice; the box or cargo will only be delivered to the exporter or
                                                consignee who appears in the invoice and will have to show
                                                identification at delivery.</li>
                                            <li>The boxes must have a security seal from the company when the consignee
                                                is going to receive it. If the invoice has detailed items, the
                                                representative will open the boxes in the presence of the consignee and
                                                check that all the items listed on the invoice are physically present.
                                                If no items are detailed on the invoice, the representative will deliver
                                                the sealed box.</li>
                                            <li>The consignee of the cargo must be in full mental and physical condition
                                                to receive the cargo; otherwise, the company will not be responsible.
                                            </li>
                                        </ul>
                                    </li>
                                    <li><strong>SHIPMENT OF VEHICLES:</strong>
                                        <ul>
                                            <li>Pickup: The company will charge for the pickup of the vehicle depending
                                                on its location. The charge is for the use of the transportation plate.
                                            </li>
                                            <li>If the vehicle breaks down along the way to the port, the customer will
                                                be responsible for the costs of towing or any other expense related to
                                                transporting it to the final destination.</li>
                                        </ul>
                                    </li>
                                    <li><strong>CLAIMS FOR VEHICLES:</strong>
                                        <ul>
                                            <li>The company is just an intermediary between the client and the shipping
                                                company; the company will not be responsible for any damages to the
                                                vehicles.</li>
                                            <li>The shipping company is responsible for any damage to the vehicles
                                                during transportation. The company will assist the client in filing the
                                                claim with the shipping company.</li>
                                        </ul>
                                    </li>
                                    <li><strong>GENERAL LIABILITY:</strong>
                                        <ul>
                                            <li>The company is not responsible for any delays caused by customs
                                                procedures, port congestion, strikes, weather conditions, or any other
                                                circumstances beyond the company’s control.</li>
                                            <li>The company reserves the right to refuse any cargo that does not comply
                                                with the company’s policies or local regulations.</li>
                                        </ul>
                                    </li>
                                    <li><strong>By signing this invoice, the consignee agrees to all the terms and
                                            conditions mentioned above.</strong></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row g-0">
                        <div class="col-lg-12 col-md-12 col-sm-12">

                            <div class="contact-info">
                                <div class="signature-row">
                                    <div class="signature-container">
                                        <div class="signature-line">
                                            <img src="<?php echo e($signatureImagePath); ?>" alt="Signature 1"
                                                class="signature-image">
                                        </div>
                                        <div class="signature-name">
                                            <p>I accept: Signture of Sender</p>
                                        </div>
                                    </div>
                                    <?php if($receiversignatureImagePath != null): ?>
                                    <div class="signature-container">
                                        <div class="signature-line">
                                            <img src="<?php echo e($receiversignatureImagePath); ?>"
                                                alt="Signature 2" class="signature-image">
                                        </div>
                                        <div class="signature-name">
                                            <p>Receiver's Signature</p>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Row -->
    <!-- -------------------------------------------------------------- -->
    <!-- End PAge Content -->
    <!-- -------------------------------------------------------------- -->

    <!-- -------------------------------------------------------------- -->
    <!-- End Container fluid  -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        function redirectToInvoices(orderNumber) {
            window.location.href = '<?php echo e(route('driver.invoice.preview', ['order_number' => ':order_number'])); ?>'.replace(
                ':order_number', orderNumber);
        }
    </script>
    <script>
        function redirectToEditInvoices(orderNumber) {

            window.location.href = '<?php echo e(route('driver.invoice.edit', ':order_number')); ?>'.replace(
                ':order_number', orderNumber);
        }
    </script>
    <script>
        function redirectToShipping(orderNumber) {

            window.location.href = '<?php echo e(route('driver.barcode.generateAndRedirect', ':order_number')); ?>'.replace(
                ':order_number', orderNumber);
        }
    </script>

    <script>
        document.getElementById('share-invoice').addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent click from closing the dropdown immediately
            const shareOptions = document.getElementById('share-options');
            shareOptions.style.display = shareOptions.style.display === 'none' ? 'block' : 'none';
        });

        // Hide dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const shareOptions = document.getElementById('share-options');
            if (!shareOptions.contains(event.target) && event.target.id !== 'share-invoice') {
                shareOptions.style.display = 'none';
            }
        });
    </script>


    <script>
        document.getElementById('gmailShareButton').addEventListener('click', function() {
            const recipientEmail = ''; // Optionally, you can specify an email here.
            const subject = encodeURIComponent('Invoice Shipment - Check Your Shipment Details');

            // Directly use the Blade route helper without additional encoding
            const invoiceLink = '<?php echo e(route('invoice.index', $orderDetails->order_number)); ?>';

            const body =
                `Dear Customer,\n\nPlease find the shipment details of your invoice at the following link:\n${invoiceLink}\n\nThank you for your purchase!\nBest regards,\nEmbarque Paton Gomez`;

            const gmailUrl =
                `https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=${recipientEmail}&su=${subject}&body=${encodeURIComponent(body)}`;

            // Open the Gmail compose window in a new tab
            window.open(gmailUrl, '_blank');
        });
    </script>
    <script>
        document.getElementById('whatsappShareButton').addEventListener('click', function() {
            // Define the message and link
            const message =
                `Dear Customer,\n\nPlease find the shipment details of your invoice at the following link:\n<?php echo e(route('invoice.index', $orderDetails->order_number)); ?>\n\nThank you !\nBest regards,\nEmbarque Paton Gomez`;

            // Encode the message for URL compatibility
            const encodedMessage = encodeURIComponent(message);

            // Create WhatsApp URL
            const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;

            // Open the WhatsApp chat in a new tab
            window.open(whatsappUrl, '_blank');
        });
    </script>

    <script>
        document.getElementById('smsShareButton').addEventListener('click', function() {
            // Define the message and link
            const message =
                `Dear Customer,\n\nPlease find the shipment details of your invoice at the following link:\n<?php echo e(route('invoice.index', $orderDetails->order_number)); ?>\n\nThank you!\nBest regards,\nEmbarque Paton Gomez`;

            // Encode the message for URL compatibility
            const encodedMessage = encodeURIComponent(message);

            // Create SMS URL (for mobile devices, the SMS app will open)
            const smsUrl = `sms:?body=${encodedMessage}`;

            // Open the SMS app with the pre-filled message
            window.location.href = smsUrl;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andy\resources\views/user/pages/invoice/invoice_preview.blade.php ENDPATH**/ ?>