<?php $__env->startSection('content'); ?>
    <!-- Page wrapper  -->
    <!-- -------------------------------------------------------------- -->

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-12 col-12 align-self-center">
            <h3 class="text-themecolor mb-0">Notification</h3>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="javascript:void(0)">Home</a>
                </li>
                <li class="breadcrumb-item active">Notification</li>
            </ol>
        </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- -------------------------------------------------------------- -->
    <!-- Container fluid  -->
    <!-- -------------------------------------------------------------- -->
    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <div class="widget-content searchable-container list">
            <div class="card card-body">
                <div class="row">
                    <div class="col-md-4 col-xl-2">
                        <form>
                            <input type="text" class="form-control product-search" id="input-search"
                                placeholder="Search Particular Notification..." />
                        </form>
                    </div>
                    <div
                        class="
                    col-md-8 col-xl-10
                    text-end
                    d-flex
                    justify-content-md-end justify-content-center
                    mt-3 mt-md-0
                  ">
                        <div class="action-btn show-btn" style="display: none">
                            <a href="javascript:void(0)"
                                class="
                        delete-multiple
                        btn-light-danger btn
                        me-2
                        text-danger
                        d-flex
                        align-items-center
                        font-weight-medium
                      ">
                                <i data-feather="trash-2" class="feather-sm fill-white me-1"></i>
                                Delete All Row</a>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- Modal -->
            
            <div class="card card-body">
                <div class="table-responsive">
                    <table class="table search-table v-middle">
                        <thead class="header-item">
                            <th>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input secondary" id="contact-check-all" />
                                        <label class="form-check-label" for="contact-check-all"></label>
                                        <span class="new-control-indicator"></span>
                                    </div>
                                </div>
                            </th>
                            <th>Titlle</th>
                            <th>Notification</th>
                            <th>Date</th>
                            <th>Type</th>

                            <th>Action</th>
                        </thead>
                        <tbody>
                            <!-- row -->
                            <tr class="search-items">
                                <td>
                                    <div class="n-chk align-self-center text-center">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input contact-chkbox primary"
                                                id="checkbox1" />
                                            <label class="form-check-label" for="checkbox1"></label>
                                        </div>
                                    </div>
                                </td>
                                <td>New Order Pickup Request</td>
                                <td>A customer has requested an order pickup.</td>
                                <td><span class="paid-badge badge bg-info px-2 py-1">2024-08-27</span></td>
                                <td><span class="paid-badge badge bg-primary px-2 py-1">Order</span></td>


                                <td>
                                    <div class="action-btn">
                                        <a href="javascript:void(0)" class="text-info edit"><i data-feather="eye"
                                                class="feather-sm fill-white"></i></a>
                                        <a href="javascript:void(0)" class="text-dark delete ms-2"><i data-feather="trash-2"
                                                class="feather-sm fill-white"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <tr class="search-items">
                                <td>
                                    <div class="n-chk align-self-center text-center">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input contact-chkbox primary"
                                                id="checkbox1" />
                                            <label class="form-check-label" for="checkbox1"></label>
                                        </div>
                                    </div>
                                </td>
                                <td>New Driver Joined</td>
                                <td>A driver has joined your company.</td>
                                <td><span class="paid-badge badge bg-info px-2 py-1">2024-08-27</span></td>
                                <td><span class="paid-badge badge bg-primary px-2 py-1">Driver</span></td>


                                <td>
                                    <div class="action-btn">
                                        <a href="javascript:void(0)" class="text-info edit"><i data-feather="eye"
                                                class="feather-sm fill-white"></i></a>
                                        <a href="javascript:void(0)" class="text-dark delete ms-2"><i data-feather="trash-2"
                                                class="feather-sm fill-white"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <tr class="search-items">
                                <td>
                                    <div class="n-chk align-self-center text-center">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input contact-chkbox primary"
                                                id="checkbox1" />
                                            <label class="form-check-label" for="checkbox1"></label>
                                        </div>
                                    </div>
                                </td>
                                <td>Order Pickup Event Today</td>
                                <td>There is a scheduled event to pick up an order today.</td>
                                <td><span class="paid-badge badge bg-info px-2 py-1">2024-08-27</span></td>
                                <td><span class="paid-badge badge bg-primary px-2 py-1">Event</span></td>


                                <td>
                                    <div class="action-btn">
                                        <a href="javascript:void(0)" class="text-info edit"><i data-feather="eye"
                                                class="feather-sm fill-white"></i></a>
                                        <a href="javascript:void(0)" class="text-dark delete ms-2"><i data-feather="trash-2"
                                                class="feather-sm fill-white"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <!-- /.row -->

                            <!-- /.row -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End PAge Content -->
        <!-- -------------------------------------------------------------- -->
    </div>
    <!-- Share Modal -->
    <div class="modal fade" id="Sharemodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form>
                    <div class="modal-header d-flex align-items-center">
                        <h5 class="modal-title" id="exampleModalLabel">
                            <i class="mdi mdi-auto-fix me-2"></i> Share With
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group mb-3">
                            <button type="button" class="btn btn-info">
                                <i class="ti-user text-white"></i>
                            </button>
                            <input type="text" class="form-control" placeholder="Enter Name Here"
                                aria-label="Username" />
                        </div>
                        <div class="row">
                            <div class="col-3 text-center">
                                <a href="#Whatsapp" class="text-success">
                                    <i class="display-6 mdi mdi-whatsapp"></i><br /><span
                                        class="text-muted">Whatsapp</span>
                                </a>
                            </div>
                            <div class="col-3 text-center">
                                <a href="#Facebook" class="text-info">
                                    <i class="display-6 mdi mdi-facebook"></i><br /><span
                                        class="text-muted">Facebook</span>
                                </a>
                            </div>
                            <div class="col-3 text-center">
                                <a href="#Instagram" class="text-danger">
                                    <i class="display-6 mdi mdi-instagram"></i><br /><span
                                        class="text-muted">Instagram</span>
                                </a>
                            </div>
                            <div class="col-3 text-center">
                                <a href="#Skype" class="text-cyan">
                                    <i class="display-6 mdi mdi-skype"></i><br /><span class="text-muted">Skype</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-paper-plane"></i> Send
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- -------------------------------------------------------------- -->
    <!-- End Container fluid  -->
    <!-- -------------------------------------------------------------- -->
    <!-- -------------------------------------------------------------- -->
    <!-- footer -->
    <!-- -------------------------------------------------------------- -->

    <!-- -------------------------------------------------------------- -->
    <!-- End footer -->
    <!-- -------------------------------------------------------------- -->

    <!-- -------------------------------------------------------------- -->
    <!-- End Page wrapper  -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(url('/')); ?>/admin/dist/js/pages/contact/contact.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starp16/public_html/andy_delacruz/resources/views/user/pages/notification/index.blade.php ENDPATH**/ ?>