<div class="month-table">
    <div class="table-responsive mt-3">
        <table class="tablesaw no-wrap v-middle table-hover table" data-tablesaw>
            <thead>
                <tr>
                    <th class="border-0 text-muted fw-normal">Order Id</th>

                    <th class="border-0 text-muted fw-normal">Old Container ID</th>
                    <th class="border-0 text-muted fw-normal">New Container ID</th>
                    <th class="border-0 text-muted fw-normal">Customer Name</th>

                    <th class="border-0 text-muted fw-normal">Payment Status</th>
                    <th class="border-0 text-muted fw-normal">View Orders</th>


                    <th class="border-0 text-muted fw-normal">Due Amount</th>

                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $leftoverPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <h6 class="font-weight-medium mb-0"><?php echo e($order->order_id); ?></h6>
                    </td>

                    <td>
                        <h6 class="font-weight-medium mb-0"  style="font-size:22px;text-decoration: line-through; text-decoration-color: red;">
                            <?php echo e($order->old_container_id); ?>

                        </h6>
                    </td>
                    <td>
                        <h6 class="font-weight-medium mb-0" style="font-size:22px;border: 2px solid green; padding: 5px;text-align:center">
                            <?php echo e($order->new_container_id); ?>

                        </h6>
                    </td>
                    <td>
                        <h6 class="font-weight-medium mb-0"> <?php echo e($order->orderPickup->sender->first_name ?? ''); ?> <?php echo e($order->orderPickup->sender->last_name ?? ''); ?></h6>
                    </td>
                    <td>
                        <button type="button" class="btn btn-sm btn-light-success text-primary custom-size"
                                data-bs-toggle="modal" data-bs-target="#paymentStatusModal"
                                data-order-pickup-id="<?php echo e($order->orderPickup->id); ?>">
                            <i data-feather="dollar-sign" class="feather-sm"></i> View
                        </button>
                    </td>
                    <td>
                        <button type="button" class="btn btn-sm btn-light-warning text-dark custom-size"
                                onclick="window.location.href='<?php echo e(route('user.order_overview', $order->orderPickup->id)); ?>'">
                            <i data-feather="package" class="feather-sm"></i> View
                        </button>

                    </td>

                    <td>

                        <span class="paid-badge badge
                        <?php echo e($order->grand_total_amount - $order->amount_paid == 0 ? 'bg-primary' : 'bg-danger'); ?>

                        px-2 py-2">
                        <?php echo e($order->grand_total_amount - $order->amount_paid == 0 ? 'PAID' : '$' . number_format($order->grand_total_amount - $order->amount_paid, 2)); ?>

                    </span>
                    </td>


                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">No Leftover Packages Added</td>
                </tr>
                <?php endif; ?>
            </tbody>


            
        </table>
    </div>
</div>


<div class="modal fade" id="addNoteModal" tabindex="-1" role="dialog" aria-labelledby="addNoteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addNoteModalLabel">Add Note</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addNoteForm">
                    <input type="hidden" id="orderPickupId" name="order_pickup_id">
                    <input type="hidden" id="orderNumber" name="order_number">
                    <div class="form-group">
                        <label for="note">Note</label>
                        <textarea class="form-control" id="note" name="add_note" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Add Note</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\andy\resources\views/admin/pages/left_over_table.blade.php ENDPATH**/ ?>