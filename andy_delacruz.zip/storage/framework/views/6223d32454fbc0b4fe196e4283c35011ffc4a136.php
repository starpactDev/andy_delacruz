<div class="month-table">
    <div class="table-responsive mt-3">
        <table class="tablesaw no-wrap v-middle table-hover table" data-tablesaw>
            <thead>
                <tr>
                    <th class="border-0 text-muted fw-normal" scope="col" class="border">
                        <label>
                            <input type="checkbox" id="selectAllCheckbox" style="margin-right: 4px" />
                            <span class="sr-only">Check All</span>
                        </label>
                        Select All
                    </th>
                    <th class="border-0 text-muted fw-normal">Order Id</th>
                    <th class="border-0 text-muted fw-normal">Customer Name</th>
                    <th class="border-0 text-muted fw-normal">Payment Status</th>
                    <th class="border-0 text-muted fw-normal">Order Status</th>
                </tr>
            </thead>
            <tbody id="orderPickupsTableBody">
                <!-- Rows will be dynamically added here -->
            </tbody>
        </table>
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\andy\resources\views/admin/pages/table1.blade.php ENDPATH**/ ?>