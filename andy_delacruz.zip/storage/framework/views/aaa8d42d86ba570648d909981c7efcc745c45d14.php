<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-5 col-12 align-self-center">
            <h3 class="text-themecolor mb-0">Employee List</h3>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="javascript:void(0)">Home</a>
                </li>
                <li class="breadcrumb-item active">Employee List</li>
            </ol>
        </div>

    </div>

    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <div class="row">
            <!-- Column -->
            <div class="col-lg-12 col-xl-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex no-block align-items-center mb-4">
                            <h4 class="card-title">Employee List</h4>
                            <div class="ms-auto">
                                <div class="btn-group">
                                    <button type="button"
                                        class="
                          btn btn-light-primary
                          text-primary
                          font-weight-medium
                          rounded-pill
                          px-4
                        "
                                        data-bs-toggle="modal" data-bs-target="#createmodel">
                                        Create New Account
                                    </button>
                                </div>
                            </div>
                        </div>
                      <div class="table-responsive">
    <table id="zero_config" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Employee Id</th>
                <th>Full Name</th>
                <th>E-mail</th>
                <th>Phone Number</th>
                <th>Address</th>
                <th>Job Position</th> <!-- New Job Position Column -->
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>001</td>
                <td>John Doe</td>
                <td>johndoe@example.com</td>
                <td>(555) 123-4567</td>
                <td>123 Elm Street, Springfield, IL</td>
                <td>US Manager</td> <!-- Job Position -->
                <td>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
                        <i class="mdi mdi-pencil" aria-hidden="true"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
                        <i class="mdi mdi-delete" aria-hidden="true"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>002</td>
                <td>Jane Smith</td>
                <td>janesmith@example.com</td>
                <td>(555) 987-6543</td>
                <td>456 Oak Avenue, Lincoln, NE</td>
                <td>RD Manager</td> <!-- Job Position -->
                <td>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
                        <i class="mdi mdi-pencil" aria-hidden="true"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
                        <i class="mdi mdi-delete" aria-hidden="true"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>003</td>
                <td>Michael Johnson</td>
                <td>michaeljohnson@example.com</td>
                <td>(555) 555-5555</td>
                <td>789 Maple Road, Denver, CO</td>
                <td>US Sub-Manager</td> <!-- Job Position -->
                <td>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
                        <i class="mdi mdi-pencil" aria-hidden="true"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
                        <i class="mdi mdi-delete" aria-hidden="true"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>004</td>
                <td>Emily Davis</td>
                <td>emilydavis@example.com</td>
                <td>(555) 654-3210</td>
                <td>321 Pine Street, Seattle, WA</td>
                <td>RD Sub-Manager</td> <!-- Job Position -->
                <td>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
                        <i class="mdi mdi-pencil" aria-hidden="true"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
                        <i class="mdi mdi-delete" aria-hidden="true"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td>005</td>
                <td>William Brown</td>
                <td>williambrown@example.com</td>
                <td>(555) 777-8888</td>
                <td>654 Cedar Drive, Austin, TX</td>
                <td>US Supervisor</td> <!-- Job Position -->
                <td>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
                        <i class="mdi mdi-pencil" aria-hidden="true"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
                        <i class="mdi mdi-delete" aria-hidden="true"></i>
                    </button>
                </td>
            </tr>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>

                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <!-- Create Modal -->
            <div class="modal fade" id="createmodel" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form>
                            <div class="modal-header d-flex align-items-center">
                                <h5 class="modal-title" id="createModalLabel">
                                    <i class="ti-marker-alt me-2"></i> Create New Employee Account
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter First Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Last Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="mail" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="email" class="form-control" placeholder="Enter E-mail Address Here"
                                        aria-label="email" />
                                </div>

                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="phone" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Phone Number Here"
                                        aria-label="no" />
                                </div>
                                <div class="input-group mb-3">
    <button type="button" class="btn btn-info">
        <i data-feather="briefcase" class="feather-sm fil-white"></i>
    </button>
    <select class="form-control" aria-label="job-position">
        <option value="" disabled selected>Select Job Position</option>
        <optgroup label="US Positions">
            <option value="us_manager">US Manager</option>
            <option value="us_sub_manager">US Sub-Manager</option>
            <option value="us_supervisor">US Supervisor</option>
            <option value="us_driver">US Driver</option>
            <option value="us_package_receiver">US Package Receiver</option>
        </optgroup>
        <optgroup label="RD Positions">
            <option value="rd_manager">RD Manager</option>
            
            <option value="rd_sub_manager">RD Sub-Manager</option>
            
            <option value="rd_supervisor">RD Supervisor</option>
            <option value="rd_driver">RD Driver</option>
            <option value="rd_package_distributor">RD Package Distributor</option>
        </optgroup>
    </select>
</div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map-pin" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Street Address Here"
                                        aria-label="address" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="home" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter City Here"
                                        aria-label="city" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter State Here"
                                        aria-label="state" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="hash" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter ZIP Code Here"
                                        aria-label="zip" />
                                </div>

                              <!-- Password Input Field -->
                              

                            <!-- Confirm Password Input Field -->
                            

                            </div>
                            <div class="modal-footer">
                                <button type="button"
                                    class="
                      btn btn-light-danger
                      text-danger
                      font-weight-medium
                      rounded-pill
                      px-4
                    "
                                    data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-success rounded-pill px-4">
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End PAge Content -->
        <!-- -------------------------------------------------------------- -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starp16/public_html/andy_delacruz/resources/views/user/pages/employee/index.blade.php ENDPATH**/ ?>