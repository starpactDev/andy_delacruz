<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($subject); ?></title>
</head>
<body>
    <p><?php echo $body; ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\andy\resources\views/emails/marketing.blade.php ENDPATH**/ ?>