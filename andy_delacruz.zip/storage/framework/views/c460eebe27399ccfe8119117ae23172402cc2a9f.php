<?php $__env->startSection('content'); ?>
    <style>
        .blue-bar {
            width: 100%;
            /* Make the bar stretch the full width */
            height: 20px;
            /* Adjust the height of the bar */
            background-color: blue;
            /* Set the color to blue */
            margin-bottom:20px;
            /* Add some space above and below the bar */
        }
          .action-buttons {
         width: 70px;
       height: 70px;
    display: flex;
    flex-direction: column;
    align-items: center; /* This centers the buttons */
    justify-content: space-between; 
}
    </style>
    <div class="row page-titles">
        <div class="col-md-5 col-12 align-self-center">
            <h3 class="text-themecolor mb-0">Drivers List</h3>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="javascript:void(0)">Home</a>
                </li>
                <li class="breadcrumb-item active">Drivers List</li>
            </ol>
        </div>

    </div>

    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <div class="row">
            <!-- Column -->
            <div class="col-lg-12 col-xl-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex no-block align-items-center mb-4">
                            <h4 class="card-title"><img src="<?php echo e(url('/')); ?>/admin/assets/images/users/usa.jpg" alt="user"
                                class="rounded-circle" width="40" /> USA DRIVERS</h4>
                            <div class="ms-auto">
                                <div class="btn-group">
                                    <button type="button"
                                        class="
                          btn btn-light-primary
                          text-primary
                          font-weight-medium
                          rounded-pill
                          px-4
                        "
                                        data-bs-toggle="modal" data-bs-target="#createmodel">
                                        Create New Account
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th class="d-none d-sm-table-cell">Driver Id</th>
                                        <th class="d-none d-sm-table-cell">Name</th>
                                        <th class="d-none d-sm-table-cell">Email</th>
                                        <th class="d-none d-sm-table-cell">Phone</th>
                                        <th class="d-none d-sm-table-cell">Address</th>
                                        <th class="d-none d-sm-table-cell">Team</th>
                                        <th class="d-none d-sm-table-cell">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1001</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">John Doe</span>
                                        </td>
                                        <td>johndoe@example.com</td>
                                        <td>+1 555-123-4567</td>
                                        <td>3344 Fir Place, Bellingham, WA 98225</td>
                                        <td>USA Team</td>
                                      <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1002</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">Jane Smith</span>
                                        </td>
                                        <td>janesmith@example.com</td>
                                        <td>+1 555-987-6543</td>
                                        <td>2211 Pine Street, Seattle, WA 98101</td>
                                        <td>USA Team</td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1003</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">Michael Johnson</span>
                                        </td>
                                        <td>michaelj@example.com</td>
                                        <td>+1 555-321-9876</td>
                                        <td>1234 Oak Avenue, Portland, OR 97232</td>
                                        <td>USA Team</td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1004</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">Emily Davis</span>
                                        </td>
                                        <td>emilydavis@example.com</td>
                                        <td>+1 555-654-3210</td>
                                        <td>4567 Maple Drive, San Francisco, CA 94107</td>
                                        <td>USA Team</td>
                                     <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1005</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">David Lee</span>
                                        </td>
                                        <td>davidlee@example.com</td>
                                        <td>+1 555-789-0123</td>
                                        <td>7890 Birch Lane, Los Angeles, CA 90001</td>
                                        <td>USA Team</td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <!-- Create Modal -->
            <div class="modal fade" id="createmodel" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form>
                            <div class="modal-header d-flex align-items-center">
                                <h5 class="modal-title" id="createModalLabel">
                                    <i class="ti-marker-alt me-2"></i> Create New Driver Account
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="download" class="feather-sm fil-white"></i>
                                    </button>
                                    <div class="custom-file">
                                        <label for="inputGroupFile01" class="form-control">Upload Profile Picture</label>
                                        <input type="file" class="form-control" id="inputGroupFile01" />
                                    </div>
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter First Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Last Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="mail" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="email" class="form-control" placeholder="Enter Email Address Here"
                                        aria-label="email" />
                                </div>

                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="phone" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Cell Number Here"
                                        aria-label="no" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map-pin" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Street Address Here"
                                        aria-label="address" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="home" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter City Here"
                                        aria-label="city" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter State Here"
                                        aria-label="state" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="hash" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter ZIP Code Here"
                                        aria-label="zip" />
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-info">
                                            <i data-feather="user" class="feather-sm fil-white"></i>
                                        </button>
                                    </div>
                                    <select class="form-control" aria-label="Role Selection">
                                        <option selected>Select Team</option>
                                        <option value="usa_team">USA Team</option>
                                        <option value="dom_team">Dominican Team</option>
                                    </select>
                                </div>
                                <!-- Password Input Field -->
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="lock" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="password" class="form-control" placeholder="Enter Password Here"
                                        aria-label="password" />
                                </div>

                                <!-- Confirm Password Input Field -->
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="lock" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="password" class="form-control" placeholder="Confirm Password Here"
                                        aria-label="confirm-password" />
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button"
                                    class="
                      btn btn-light-danger
                      text-danger
                      font-weight-medium
                      rounded-pill
                      px-4
                    "
                                    data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-success rounded-pill px-4">
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <div class="blue-bar"></div>

        <div class="row">
            <!-- Column -->
            <div class="col-lg-12 col-xl-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex no-block align-items-center mb-4">
                            <h4 class="card-title"><img src="<?php echo e(url('/')); ?>/admin/assets/images/users/dom.jpg" alt="user"
                                class="rounded-circle" width="40" /> DOMINICAN REPUBLIC DRIVERS</h4>
                            <div class="ms-auto">
                                <div class="btn-group">
                                    <button type="button"
                                        class="
                          btn btn-light-primary
                          text-primary
                          font-weight-medium
                          rounded-pill
                          px-4
                        "
                                        data-bs-toggle="modal" data-bs-target="#createmodel">
                                        Create New Account
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="default_order" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Driver Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Team</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1001</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">John Doe</span>
                                        </td>
                                        <td>johndoe@example.com</td>
                                        <td>+1 555-123-4567</td>
                                        <td>3344 Fir Place, Bellingham, WA 98225</td>
                                        <td>Dominican Team</td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1002</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">Jane Smith</span>
                                        </td>
                                        <td>janesmith@example.com</td>
                                        <td>+1 555-987-6543</td>
                                        <td>2211 Pine Street, Seattle, WA 98101</td>
                                        <td>Dominican Team</td>
                                        <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1003</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">Michael Johnson</span>
                                        </td>
                                        <td>michaelj@example.com</td>
                                        <td>+1 555-321-9876</td>
                                        <td>1234 Oak Avenue, Portland, OR 97232</td>
                                        <td>Dominican Team</td>
                                       <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1004</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">Emily Davis</span>
                                        </td>
                                        <td>emilydavis@example.com</td>
                                        <td>+1 555-654-3210</td>
                                        <td>4567 Maple Drive, San Francisco, CA 94107</td>
                                        <td>Dominican Team</td>
                                        <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1005</td>
                                        <td>
                                            <img src="<?php echo e(url('/')); ?>/admin/assets/images/users/4.jpg" alt="user"
                                                class="rounded-circle" width="30" />
                                            <span class="fw-normal">David Lee</span>
                                        </td>
                                        <td>davidlee@example.com</td>
                                        <td>+1 555-789-0123</td>
                                        <td>7890 Birch Lane, Los Angeles, CA 90001</td>
                                        <td>Dominican Team</td>
                                       
                                        <td>
                                              <div class="action-buttons">
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-warning edit-row-btn" data-bs-toggle="tooltip" data-original-title="Edit">
            <i class="mdi mdi-pencil" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-pure btn-outline btn-danger delete-row-btn" data-bs-toggle="tooltip" data-original-title="Delete">
            <i class="mdi mdi-delete" aria-hidden="true"></i>
        </button>
    </div>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <!-- Column -->
            <!-- Create Modal -->
            <div class="modal fade" id="createmodel" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form>
                            <div class="modal-header d-flex align-items-center">
                                <h5 class="modal-title" id="createModalLabel">
                                    <i class="ti-marker-alt me-2"></i> Create New Driver Account
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="download" class="feather-sm fil-white"></i>
                                    </button>
                                    <div class="custom-file">
                                        <label for="inputGroupFile01" class="form-control">Upload Profile Picture</label>
                                        <input type="file" class="form-control" id="inputGroupFile01" />
                                    </div>
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter First Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="user" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Last Name Here"
                                        aria-label="name" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="mail" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="email" class="form-control" placeholder="Enter Email Address Here"
                                        aria-label="email" />
                                </div>

                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="phone" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Cell Number Here"
                                        aria-label="no" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map-pin" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter Street Address Here"
                                        aria-label="address" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="home" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter City Here"
                                        aria-label="city" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="map" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter State Here"
                                        aria-label="state" />
                                </div>
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="hash" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="text" class="form-control" placeholder="Enter ZIP Code Here"
                                        aria-label="zip" />
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-info">
                                            <i data-feather="user" class="feather-sm fil-white"></i>
                                        </button>
                                    </div>
                                    <select class="form-control" aria-label="Role Selection">
                                        <option selected>Select Team</option>
                                        <option value="usa_team">USA Team</option>
                                        <option value="dom_team">Dominican Team</option>
                                    </select>
                                </div>
                                <!-- Password Input Field -->
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="lock" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="password" class="form-control" placeholder="Enter Password Here"
                                        aria-label="password" />
                                </div>

                                <!-- Confirm Password Input Field -->
                                <div class="input-group mb-3">
                                    <button type="button" class="btn btn-info">
                                        <i data-feather="lock" class="feather-sm fil-white"></i>
                                    </button>
                                    <input type="password" class="form-control" placeholder="Confirm Password Here"
                                        aria-label="confirm-password" />
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button"
                                    class="
                      btn btn-light-danger
                      text-danger
                      font-weight-medium
                      rounded-pill
                      px-4
                    "
                                    data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-success rounded-pill px-4">
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End PAge Content -->
        <!-- -------------------------------------------------------------- -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starp16/public_html/andy_delacruz/resources/views/user/pages/driver/index.blade.php ENDPATH**/ ?>