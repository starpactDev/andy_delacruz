<?php $__env->startSection('content'); ?>
    <style>
        .title {
            color: rgb(10, 78, 99);
        }

        .btn {
            margin-right: 5px;
        }

        .top-right-buttons {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .top-right-buttons button {
            margin-left: 10px;
        }

        .signature-row {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .signature-container {
            width: 45%;
            /* Adjust the width as needed */
        }

        .signature-line {
            border-bottom: 1px solid #000;
            width: 100%;
            height: 50px;
            /* Adjust the height as needed */
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .signature-image {
            max-height: 100%;
            /* Ensure the image fits within the line */
            max-width: 100%;
        }

        .signature-name {
            text-align: center;
            margin-top: 5px;
            font-size: 16px;
        }

        .important-notes-list-1 li {
            margin-bottom: 10px;
            font-size: 12.5px;
        }

        .font-weight-bold {
            font-weight: bold;
        }

        ul {
            color: #000 !important;
        }



    </style>
    <!-- -------------------------------------------------------------- -->
    <div class="container-fluid">
        <!-- -------------------------------------------------------------- -->
        <!-- Start Page Content -->
        <!-- -------------------------------------------------------------- -->
        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="top-right-buttons">
                    <button class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Send Invoice
                    </button>
                    <button class="btn btn-info" onclick="redirectToInvoices()">
                        <i class="fas fa-print"></i> Proceed to Print
                    </button>
                    <button class="btn btn-success" id="invoice_download_btn">
                        <i class="fas fa-download"></i> Download
                    </button>

                    <button class="btn btn-secondary">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-body printableArea">
                    <h3><b>INVOICE</b> <span class="pull-right"># EPG 20-0001</span></h3>
                    <hr />
                    <div class="row">
                        <div class="col-md-12">
                            <div class="pull-right ">
                                <div class="invoice-logo">
                                    <!-- logo started -->
                                    <div class="logo">
                                        <img src="<?php echo e(url('/')); ?>/admin/assets/images/andy.png" alt="logo" />
                                    </div>
                                    <!-- logo ended -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="invoice-number mb-30">
                                <h4 class="inv-title-1">Address 1</h4>
                                <h6 class="name"><i class="fa fa-map-marker" style="margin-right: 5px;"></i>3115
                                    WASHINGTON STREET</h6>
                                <p class="invo-addr-1 mt-10">
                                    ROXBURY, MA. 02130 <br />
                                    617-477-9072 <br />
                                    781-439-2046<br />
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="invoice-number mb-30">
                                <h4 class="inv-title-1">Address 2</h4>
                                <h6 class="name"><i class="fa fa-map-marker" style="margin-right: 5px;"></i>57 CHASE
                                    STREET</h6>
                                <p class="invo-addr-1 mt-10">
                                    METHUEN, MA 01844 <br />
                                    978-258-0238 <br />
                                    978-258-0154<br />
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="invoice-number mb-30">
                                <h4 class="inv-title-1">Address 3</h4>
                                <h6 class="name"><i class="fa fa-map-marker" style="margin-right: 5px;"></i>BANI,
                                    DOMINICAN REPUBLIC</h6>
                                <p class="invo-addr-1 mt-10">
                                    ANA PRAVIA STREET # 99 PERAVIA <br />
                                    809-522-3648 <br />
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <address>
                                <h4 class="fw-bold" style="color:#4d545a">Invoice:</h4>
                                <p>
                                    <b>Invoice #: </b>EPG 20-0001 <br />
                                    <b>Issue Date: </b>13 Sep 2024 <br />
                                    <b>Order ID: </b>EPG-4096 <br />
                                    <b>Container ID: </b>EPG 20 <br />
                                    <b>Driver Name: </b>Jose Manuel Gonzalbz
                                </p>
                            </address>
                        </div>
                    </div>
                    <hr />
                    <div class="row  d-flex justify-content-between">
                        <div class="col-md-6" style=" padding-right: 10px;">
                            <address>
                                <h4 class="fw-bold">Sender:</h4>
                                <h5>Harry Doe</h5>
                                <p class="text-muted">
                                    <b>Email:&nbsp;</b>redq@company.com <br />
                                    <b>Tel:&nbsp;</b> 128-666-0707 <br />
                                    <b>Cell:&nbsp;</b>128-586-0707 <br />
                                    <b>Address:&nbsp;</b>405 Mulberry Rd <br />
                                    <b>City:&nbsp;</b> Mc Grady<br />
                                    <b>State:&nbsp;</b>NC <br />
                                    <b>Zip:&nbsp;</b>28649 <br />
                                </p>
                            </address>
                        </div>
                        <div class="col-md-6 " style=" padding-right: 10px;">
                            <address>
                                <h4 class="fw-bold">Receiver:</h4>
                                <h5>John Doe</h5>
                                <p class="text-muted">
                                    <b>Email:&nbsp;</b>redq@company.com <br />
                                    <b>Tel:&nbsp;</b> 128-666-0707 <br />
                                    <b>Cell:&nbsp; </b> 128-666-0707 <br />
                                    <b>WhatsApp:&nbsp;</b> 128-666-0707 <br />
                                    <b>Address:&nbsp;</b>405 Mulberry Rd, Mc Grady<br />

                                    <b>Neighbourhood:&nbsp;</b> 406 Mulberry Rd, Mc Grady<br />

                                    <b>City:&nbsp;</b> City Name <br />
                                    <b>Province:&nbsp;</b> El Saibo <br />
                                </p>
                            </address>
                        </div>
                        
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive m-t-40" style="clear: both">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th>Items</th>
                                            <th class="text-end">QTY</th>
                                            <th class="text-end">Price</th>
                                            <th class="text-end">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center">1</td>
                                            <td>Calendar App Customization</td>
                                            <td class="text-end">1</td>
                                            <td class="text-end">$120</td>
                                            <td class="text-end">$120</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">2</td>
                                            <td>Chat App Customization</td>
                                            <td class="text-end">1</td>
                                            <td class="text-end">$230</td>
                                            <td class="text-end">$230</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">3</td>
                                            <td>Laravel Integration</td>
                                            <td class="text-end">1</td>
                                            <td class="text-end">$405</td>
                                            <td class="text-end">$405</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">4</td>
                                            <td>Backend UI Design</td>
                                            <td class="text-end">1</td>
                                            <td class="text-end">$2500</td>
                                            <td class="text-end">$2500</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="pull-right m-t-30 text-end">
                                <table class="table invoice-summary-table">
                                    <tr class="sub-total-row">
                                        <td><b>Sub - Total:</b></td>
                                        <td>$3255</td>
                                    </tr>


                                    <tr class="sub-total-row">
                                        <td><b>Discount:</b></td>
                                        <td>$10</td>
                                    </tr>
                                    <tr class="sub-total-row">
                                        <td>

                                        </td>
                                        <td>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h3><b>Grand Total:</b></h3>
                                        </td>
                                        <td>
                                            <h3>$3945</h3>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Deposit/Value Paid:</b></td>
                                        <td>
                                            <h3 style="color: green">$10</h3>
                                        </td>
                                    </tr>
                                    <tr class="sub-total-row">
                                        <td><b>Balance Due :</b></td>
                                        <td>
                                            <h3 style="color: red">$3935</h3>
                                        </td>
                                    </tr>
                                    <tr class="payment-method-row">
                                        <td><b>Payment Methods:</b></td>
                                        <td>
                                            <table class="table invoice-summary-table">
                                                <tbody>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="cash">Cash
                                                                (US)</label></td>
                                                    </tr>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="paypal">Paypal</label>
                                                        </td>
                                                    </tr>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="zelle">Zelle</label>
                                                        </td>
                                                    </tr>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="cashApp">Cash
                                                                App</label></td>
                                                    </tr>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="creditCard">Credit
                                                                Cards</label></td>
                                                    </tr>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="payLater">Pay
                                                                Later</label></td>
                                                    </tr>
                                                    <tr class="sub-total-row">
                                                        
                                                        <td><label class="form-check-label" for="bankDeposit">Bank
                                                                Deposit (Chase Bank # 597817520)</label></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr class="sub-total-row">
                                        <td><b>Payment Location :</b></td>
                                        <td><b>Dom Rep</b></td>
                                    </tr>

                                    <tr class="sub-total-row">
                                        <td><b>Total packages to be delivered :</b></td>
                                        <td><b>4</b></td>
                                    </tr>

                                </table>
                            </div>
                            <div class="clearfix"></div>

                        </div>
                    </div>
                    <hr>
                    <hr>
                    <div class="row mb-4 mt-4">
                        <div class="col-sm-12">
                            <div class="important-note" style="margin-top:35px">
                                <h5 class="inv-title-1 text-center" style="color:red!important">COMPANY POLICY</h5>
                                <ul class="important-notes-list-1">
                                    <li> WE ARE NOT RESPONSIBLE FOR GOODS FOR DAMAGE FROM FIRE OR FLOODS.</li>
                                    <li> We thank you if you save your invoice for future claims or inconveniences.</li>
                                    <li>If you pay immediately, you will be one of the first customers to receive your
                                        merchandise.</li>
                                    <li> We pay 5% on the declared value</li>
                                    <li> Any UNPAID package that remains in our warehouse in the Dominican Republic for
                                        more than 15 days will be auctioned and the resources obtained through the
                                        auction will be
                                        used to cover the costs of your package.</li>
                                </ul>
                                <h5 class="font-weight-bold" style="font-size:16px">Contrato/Contract</h5>
                                <ul class="important-notes-list-1">
                                    <li><strong>Receiving Cargo:</strong>
                                        <ul>
                                            <li>At the time of receiving cargo, the consignee must check it to make sure
                                                that everything is okay. He or she must sign a document and, as soon as
                                                the consignee signs such document, neither the exporter nor the
                                                consignee will have any rights to complain for lost or damaged items.
                                            </li>
                                            <li>Any cargo with balance left more than fifteen days in our warehouse will
                                                be charged a 5% of the freight charge every fifteen days. If the company
                                                does not receive any payments during the next three months, the customer
                                                will lose the cargo, and the company will reserve the rights to do
                                                anything with it.</li>
                                            <li>The company is not responsible for any illegal items contained in the
                                                packages.</li>
                                        </ul>
                                    </li>
                                    <li><strong>NOTE:</strong> The company agrees to pay for the articles in case of
                                        loss or irreparable damage, as follows:
                                        <ul>
                                            <li>To new articles, a 10% of the value of the freight is charged as an
                                                additional insurance policy. In case of loss or irreparable damage, the
                                                client will receive payment of the total value of the good in the market
                                                as new. The client must show the original receipt from the store where
                                                it was purchased.</li>
                                            <li>To used articles, a 5% of the value of the freight is charged as an
                                                additional insurance policy. In case of loss or irreparable damage, the
                                                client will receive payment of 25% of the value of the article in the
                                                market.</li>
                                            <li>In case of loss, the client will only receive payment for values
                                                declared on this invoice.</li>
                                        </ul>
                                    </li>
                                    <li><strong>CLAIMS:</strong>
                                        <ul>
                                            <li>We only accept claims at the time of receiving the cargo. After items
                                                have been received, in case damage has occurred it will only be replaced
                                                if such damage cannot be repaired. The company will not replace the item
                                                for cash, it will only be replaced with one similar if it cannot be
                                                repaired.</li>
                                        </ul>
                                    </li>
                                    <li><strong>BOXES OF PERSONAL BELONGINGS:</strong>
                                        <ul>
                                            <li>Must be 18”X18”X28”. In these boxes, new articles are not accepted
                                                without being declared; articles by dozen are not accepted nor for
                                                commercial use.</li>
                                            <li>In case of loss of a box of personal belongings, the company will pay a
                                                maximum of $100.00 dollars per box after an investigation has been made,
                                                and a credit will be given for another box of the same dimensions
                                                (18”X18”X28”).</li>
                                            <li>The same clauses apply to boxes of used clothes. Jewelry or cell phones
                                                are not accepted, and any article whose value exceeds $30.00 must be
                                                declared.</li>
                                        </ul>
                                    </li>
                                    <li><strong>CLAIMS FOR BROKEN LAMPS OR GLASSES:</strong>
                                        <ul>
                                            <li>The company is not responsible for lamps or glasses packed by anyone
                                                other than this company’s employees; it will only pay a maximum of
                                                $100.00 for irreparable broken lamps or glasses.</li>
                                        </ul>
                                    </li>
                                    <li><strong>DELIVERY OF BOXES:</strong>
                                        <ul>
                                            <li>The company is only responsible for new articles declared in the
                                                invoice; the box or cargo will only be delivered to the exporter or
                                                consignee who appears in the invoice and will have to show
                                                identification at delivery.</li>
                                            <li>The boxes must have a security seal from the company when the consignee
                                                is going to receive it. If the invoice has detailed items, the
                                                representative will open the boxes in the presence of the consignee and
                                                check that all the items listed on the invoice are physically present.
                                                If no items are detailed on the invoice, the representative will deliver
                                                the sealed box.</li>
                                            <li>The consignee of the cargo must be in full mental and physical condition
                                                to receive the cargo; otherwise, the company will not be responsible.
                                            </li>
                                        </ul>
                                    </li>
                                    <li><strong>SHIPMENT OF VEHICLES:</strong>
                                        <ul>
                                            <li>Pickup: The company will charge for the pickup of the vehicle depending
                                                on its location. The charge is for the use of the transportation plate.
                                            </li>
                                            <li>If the vehicle breaks down along the way to the port, the customer will
                                                be responsible for the costs of towing or any other expense related to
                                                transporting it to the final destination.</li>
                                        </ul>
                                    </li>
                                    <li><strong>CLAIMS FOR VEHICLES:</strong>
                                        <ul>
                                            <li>The company is just an intermediary between the client and the shipping
                                                company; the company will not be responsible for any damages to the
                                                vehicles.</li>
                                            <li>The shipping company is responsible for any damage to the vehicles
                                                during transportation. The company will assist the client in filing the
                                                claim with the shipping company.</li>
                                        </ul>
                                    </li>
                                    <li><strong>GENERAL LIABILITY:</strong>
                                        <ul>
                                            <li>The company is not responsible for any delays caused by customs
                                                procedures, port congestion, strikes, weather conditions, or any other
                                                circumstances beyond the company’s control.</li>
                                            <li>The company reserves the right to refuse any cargo that does not comply
                                                with the company’s policies or local regulations.</li>
                                        </ul>
                                    </li>
                                    <li><strong>By signing this invoice, the consignee agrees to all the terms and
                                            conditions mentioned above.</strong></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row g-0">
                        <div class="col-lg-12 col-md-12 col-sm-12">

                            <div class="contact-info">
                                <div class="signature-row">
                                    <div class="signature-container">
                                        <div class="signature-line">
                                            <img src="<?php echo e(url('/')); ?>/invoice/assets/img/sign.png" alt="Signature 1"
                                                class="signature-image">
                                        </div>
                                        <div class="signature-name">
                                            <p>I accept: Signture of Sender</p>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Row -->
    <!-- -------------------------------------------------------------- -->
    <!-- End PAge Content -->
    <!-- -------------------------------------------------------------- -->

    <!-- -------------------------------------------------------------- -->
    <!-- End Container fluid  -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    function redirectToInvoices() {
        window.location.href = '<?php echo e(route('user.invoice.index')); ?>';
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andy\resources\views/user/pages/invoice/dmo.blade.php ENDPATH**/ ?>